export const environment = {
  production: true,
  apiUrl: 'https://apispring.icstartup.academy/api/',
  imgUrl:'https://apispring.icstartup.academy/'
};
