import { TestBed } from '@angular/core/testing';

import { CategoriefournitureService } from './categoriefourniture.service';

describe('CategoriefournitureService', () => {
  let service: CategoriefournitureService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CategoriefournitureService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
