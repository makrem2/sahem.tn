import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PartenaireService {

  constructor(private http: HttpClient) { 


  }

  addPartenaire(Partenaire: any) {
    return this.http.post(environment.apiUrl + 'Partenaire/addPartenaire', Partenaire);
  }

  getAllPartenaire() {
    return this.http.get(environment.apiUrl + 'Partenaire/getAllPartenaire');
  }

  deletePartenaire(idPartenaire: any) {
    return this.http.delete(
      environment.apiUrl + 'Partenaire/deletePartenaire/' + idPartenaire
    );
  }
}
