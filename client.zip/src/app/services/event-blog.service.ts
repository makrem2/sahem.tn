import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class EventBlogService {
  constructor(private http: HttpClient) {}

  //*****************  CRUD Event         **************************** */

  addEvent(event: any) {
    return this.http.post(environment.apiUrl + 'event/addEvent', event);
  }

  getAllEvent() {
    return this.http.get(environment.apiUrl + 'event/getAllEvent');
  }

  getOneEvent(idEvent: any) {
    return this.http.get(environment.apiUrl + 'event/getOneEvent/' + idEvent);
  }

  getAllUserEvent(iduser: any) {
    return this.http.get(
      environment.apiUrl + 'event/getAllUserEvent/' + iduser
    );
  }

  updateEvent(idEvent: any, event: any) {
    return this.http.patch(
      environment.apiUrl + 'event/updateEvent/' + idEvent,
      event
    );
  }

  deleteEvent(idEvent: any) {
    return this.http.delete(
      environment.apiUrl + 'event/deleteEvent/' + idEvent
    );
  }

  //*****************  CRUD Blog         **************************** */

  addBlog(Blog: any) {
    return this.http.post(environment.apiUrl + 'blog/addBlog', Blog);
  }

  getAllBlog() {
    return this.http.get(environment.apiUrl + 'blog/getAllBlog');
  }

  getAllUserBlog(userid: any) {
    return this.http.get(environment.apiUrl + 'blog/getAllUserBlog/' + userid);
  }

  getOneBlog(idBlog: any) {
    return this.http.get(environment.apiUrl + 'blog/getOneBlog/' + idBlog);
  }

  updateBlog(idBlog: any, Blog: any) {
    return this.http.patch(
      environment.apiUrl + 'blog/updateBlog/' + idBlog,
      Blog
    );
  }

  deleteBlog(idBlog: any) {
    return this.http.delete(environment.apiUrl + 'blog/deleteBlog/' + idBlog);
  }
}
