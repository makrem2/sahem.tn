import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserServiceService {
  constructor(private http: HttpClient) {}

  AddUser(user: any) {
    return this.http.post(environment.apiUrl + 'auth/signup', user);
  }

  getAllUser() {
    return this.http.get(environment.apiUrl + 'auth/getAllUser');
  }

  getOneUser(id: any) {
    return this.http.get(environment.apiUrl + 'auth/getOneUser/' + id);
  }

  getAlluserByRole(role: any) {
    return this.http.get(environment.apiUrl + 'auth/getAlluserByRole/' + role);
  }

  getAllUserByRegion(address: any) {
    return this.http.get(
      environment.apiUrl + 'auth/getAllUserByRegion/' + address
    );
  }

  updateUser(userid: any, userdata: any) {
    return this.http.patch(
      environment.apiUrl + 'auth/updateUser/' + userid,
      userdata
    );
  }

  updateAdminUser(userid: any, userdata: any) {
    return this.http.patch(
      environment.apiUrl + 'auth/updateAdminUser/' + userid,
      userdata
    );
  }

  getAlluserByRoleANDAdress(role:any,adress:any){
    return this.http.get(
      environment.apiUrl + 'auth/getAlluserByRoleANDAdress/' +
      role +
      '/' +
      adress
  );
  }

  updateUserImage(userid: any, userphoto: any) {
    return this.http.patch(
      environment.apiUrl + 'auth/updateUserImage/' + userid,
      userphoto
    );
  }

  deleteUser(userid: any) {
    return this.http.delete(environment.apiUrl + 'auth/deleteUser/' + userid);
  }

  SendMailAssoicationAfterRegister(data: any) {
    return this.http.post(environment.apiUrl + 'contact', data);
  }
}
