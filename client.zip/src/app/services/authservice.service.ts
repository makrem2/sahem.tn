import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { JwtHelperService } from '@auth0/angular-jwt';

const TOKEN_KEY = 'auth-token';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root',
})
export class AuthserviceService {
  helper = new JwtHelperService();
  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http.post(environment.apiUrl + 'auth/signin', data,httpOptions);
  }

  register(data:any){
    return this.http.post(environment.apiUrl + 'auth/signup', data);
  }

  SaveDataProfile(data: any) {
    localStorage.clear();
    localStorage.setItem('ROLE_KEY', data.roles);
    localStorage.setItem(TOKEN_KEY, data.accessToken);
  }

  getUserid() {
    let token: any = localStorage.getItem(TOKEN_KEY);
    let decodeToken = this.helper.decodeToken(token);
    return decodeToken.id;
  }

  Lougout() {
    localStorage.clear();
  }


  public getToken(): string | null {
    return window.localStorage.getItem(TOKEN_KEY);
  }

  AdminisLoggedIN() {
    let token: any = localStorage.getItem(TOKEN_KEY);

    if (!localStorage.getItem(TOKEN_KEY)) {
      return false;
    }

    if (localStorage.getItem('ROLE_KEY') !== 'ROLE_ADMIN') {
      return false;
    }
    if (this.helper.isTokenExpired(token)) {
      return false;
    }
    return true;
  }

  AssociationisLoggedIN() {
    let token: any = localStorage.getItem(TOKEN_KEY);

    if (!localStorage.getItem(TOKEN_KEY)) {
      return false;
    }

    if (localStorage.getItem('ROLE_KEY') !== 'ROLE_ASSOCIATION') {
      return false;
    }
    if (this.helper.isTokenExpired(token)) {
      return false;
    }
    return true;
  }
  UserisLoggedIN() {
    let token: any = localStorage.getItem(TOKEN_KEY);

    if (!localStorage.getItem(TOKEN_KEY)) {
      return false;
    }

    if (localStorage.getItem('ROLE_KEY') !== 'ROLE_USER') {
      return false;
    }
    if (this.helper.isTokenExpired(token)) {
      return false;
    }
    return true;
  }
}
