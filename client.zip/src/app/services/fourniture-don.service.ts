import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class FournitureDonService {
  constructor(private http: HttpClient) {}

  //*****************  CRUD Don        **************************** */
  adddon(don: any) {
    return this.http.post(environment.apiUrl + 'don/adddon', don);
  }
  getAllDon() {
    return this.http.get(environment.apiUrl + 'don/getAllDon');
  }
  validerledon(iddon: any, etat: any) {
    return this.http.patch(
      environment.apiUrl + 'don/validerledon/' + iddon,
      etat
    );
  }
  deleteDon(iddon: any) {
    return this.http.delete(environment.apiUrl + 'don/deleteDon/' + iddon);
  }

  deleteDonParCode(code: any) {
    return this.http.delete(
      environment.apiUrl + 'don/deleteDonParCode/' + code
    );
  }

  getDonByRegion(region: any) {
    return this.http.get(environment.apiUrl + 'don/getDonByRegion/' + region);
  }
  getdonOfUser(iduser: any) {
    return this.http.get(environment.apiUrl + 'don/getdonOfUser/' + iduser);
  }
  getDonByCode(codedon: any) {
    return this.http.get(environment.apiUrl + 'don/getDonByCode/' + codedon);
  }

  getDonParEtat(etat: any) {
    return this.http.get(environment.apiUrl + 'don/getDonParEtat/' + etat);
  }

  getAllAssociationDonBYEtat(etat: any, adress: any) {
    return this.http.get(
      environment.apiUrl +
        'don/getAllAssociationDonBYEtat/' +
        etat +
        '/' +
        adress
    );
  }

  //*****************  CRUD  Fourniture       **************************** */

  addFourniture(Fourniture: any) {
    return this.http.post(
      environment.apiUrl + 'fourniture/addFourniture',
      Fourniture
    );
  }
  getAllFourniture() {
    return this.http.get(environment.apiUrl + 'fourniture/getAllFourniture');
  }
  getAllFournitureBydonId(donId: any) {
    return this.http.get(
      environment.apiUrl + 'fourniture/getAllFournitureBydonId/' + donId
    );
  }
  deleteFourniture(IdFourniture: any) {
    return this.http.delete(
      environment.apiUrl + 'fourniture/deleteFourniture/' + IdFourniture
    );
  }
}
