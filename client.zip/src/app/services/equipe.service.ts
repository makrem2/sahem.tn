import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class EquipeService {
  constructor(private http: HttpClient) {}

  addEquipe(equipe: any) {
    return this.http.post(environment.apiUrl + 'Equipe/addEquipe', equipe);
  }

  getAllEquipe() {
    return this.http.get(environment.apiUrl + 'Equipe/getAllEquipe');
  }

  deleteEquipe(idequipe: any) {
    return this.http.delete(
      environment.apiUrl + 'Equipe/deleteEquipe/' + idequipe
    );
  }
}
