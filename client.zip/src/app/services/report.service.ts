import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { }

//*****************  CRUD Category         **************************** */

addReportBesoin(besoin: any){
  return this.http.post(environment.apiUrl + 'Report/addReportBesoin', besoin);
}


addReport(besoin: any) {
  return this.http.post(environment.apiUrl + 'Report/addReport', besoin);
}

getAllReport() {
  return this.http.get(environment.apiUrl + 'Report/getAllReport');
}

deleteReport(idbesoin: any) {
  return this.http.delete(
    environment.apiUrl + 'Report/deleteReport/' + idbesoin
  );
}

}
