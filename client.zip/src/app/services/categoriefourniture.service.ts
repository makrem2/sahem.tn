import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CategoriefournitureService {
  constructor(private http: HttpClient) {}

  //*****************  CRUD Category         **************************** */

  addCategory(categorie: any) {
    return this.http.post(
      environment.apiUrl + 'category/addCategory',
      categorie
    );
  }

  getOneCategory(idcategorie: any) {
    return this.http.get(
      environment.apiUrl + 'category/getOneCategory/' + idcategorie
    );
  }

  getAllCategorys() {
    return this.http.get(environment.apiUrl + 'category/getAllCategorys');
  }

  updateCategory(idcategorie: any, categorie: any) {
    return this.http.patch(
      environment.apiUrl + 'category/updateCategory/' + idcategorie,
      categorie
    );
  }

  deletecategorie(idcategorie: any) {
    return this.http.delete(
      environment.apiUrl + 'category/deletecategorie/' + idcategorie
    );
  }

  // ******************CRUD Fournitures ************************************************

  addFournitures(Fournitures: any) {
    return this.http.post(
      environment.apiUrl + 'fourniture/addType_fourniture',
      Fournitures
    );
  }

  getOneFournitures(idFournitures: any) {
    return this.http.get(
      environment.apiUrl + 'fourniture/getOneType_fourniture/' + idFournitures
    );
  }

  getType_fournitureByCategorie(idCategorie: any) {
    return this.http.get(
      environment.apiUrl +
        'fourniture/getType_fournitureByCategorie/' +
        idCategorie
    );
  }

  getAllFournitures() {
    return this.http.get(
      environment.apiUrl + 'fourniture/getAllType_fourniture'
    );
  }

  updateFournitures(idFournitures: any, Fournitures: any) {
    return this.http.patch(
      environment.apiUrl + 'fourniture/updateType_fourniture/' + idFournitures,
      Fournitures
    );
  }

  deleteFournitures(idFournitures: any) {
    return this.http.delete(
      environment.apiUrl + 'fourniture/deleteType_fourniture/' + idFournitures
    );
  }
}
