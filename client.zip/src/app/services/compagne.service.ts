import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class CompagneService {
  constructor(private http: HttpClient) {}

  //*****************  CRUD Compagne         **************************** */

  addCompagne(compagne: any) {
    return this.http.post(
      environment.apiUrl + 'compagne/addCompagne',
      compagne
    );
  }

  getOneCompagne(idcategorie: any) {
    return this.http.get(
      environment.apiUrl + 'compagne/getOneCompagne/' + idcategorie
    );
  }

  getAllUserCompagne(idUser: any) {
    return this.http.get(
      environment.apiUrl + 'compagne/getAllUserCompagne/' + idUser
    );
  }

  getAllCompagnes() {
    return this.http.get(environment.apiUrl + 'compagne/getAllCompagne');
  }

  updateCompagne(idcompagne: any, compagne: any) {
    return this.http.patch(
      environment.apiUrl + 'compagne/updateCompagne/' + idcompagne,
      compagne
    );
  }

  deletecompagne(idcompagne: any) {
    return this.http.delete(
      environment.apiUrl + 'compagne/deleteCompagne/' + idcompagne
    );
  }
}
