import { HttpClient, HttpHeaders } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class BesoinService {
  constructor(private http: HttpClient) {}

  //*****************  CRUD Category         **************************** */

  addbesoin(besoin: any) {
    return this.http.post(environment.apiUrl + 'besoin/addBesoin', besoin);
  }

  getOnebesoin(idbesoin: any) {
    return this.http.get(
      environment.apiUrl + 'besoin/getOneBesoin/' + idbesoin
    );
  }

  getAllUserBesion(idUser: any) {
    return this.http.get(
      environment.apiUrl + 'besoin/getAllUserBesion/' + idUser
    );
  }

  getAllBesionBYAdress(adress: any) {
    return this.http.get(
      environment.apiUrl + 'besoin/getAllBesionBYAdress/' + adress
    );
  }

  getAllbesoin() {
    return this.http.get(environment.apiUrl + 'besoin/getAllBesoins');
  }

  updatebesoin(idbesoin: any, categorie: any) {
    return this.http.patch(
      environment.apiUrl + 'besoin/updateBesoin/' + idbesoin,
      categorie
    );
  }

  deletebesoin(idbesoin: any) {
    return this.http.delete(
      environment.apiUrl + 'besoin/deletebesoin/' + idbesoin
    );
  }

  updateEtat(idbesoin: any, besoin: any) {
    return this.http.patch(
      environment.apiUrl + 'besoin/updateEtat/' + idbesoin,
      besoin
    );
  }

  getAllBesionBYEtat(etat: any) {
    return this.http.get(
      environment.apiUrl + 'besoin/getAllBesionBYEtat/' + etat
    );
  }

  getAllAssociationBesionBYEtat(etat:any,adress:any){
    return this.http.get(
      environment.apiUrl + 'besoin/getAllAssociationBesionBYEtat/' +
      etat +
      '/' +
      adress
  );
  }
}
