import { TestBed } from '@angular/core/testing';

import { FournitureDonService } from './fourniture-don.service';

describe('FournitureDonService', () => {
  let service: FournitureDonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FournitureDonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
