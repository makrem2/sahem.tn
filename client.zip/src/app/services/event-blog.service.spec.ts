import { TestBed } from '@angular/core/testing';

import { EventBlogService } from './event-blog.service';

describe('EventBlogService', () => {
  let service: EventBlogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EventBlogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
