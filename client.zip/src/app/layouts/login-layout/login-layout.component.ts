import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { NotificationService } from 'src/app/services/notification.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login-layout',
  templateUrl: './login-layout.component.html',
  styleUrls: ['./login-layout.component.css'],
})
export class LoginLayoutComponent implements OnInit {
  visible: boolean = true;
  changetype: boolean = true;
  dataRecevie: any;
  messageError: any;
  messageSucces: any;
  urlAdmin: any;
  urlAssociation: any;
  constructor(
    private authadmin: AuthserviceService,
    private router: Router,
    private notifyService: NotificationService,
    private ActRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {

    this.urlAdmin = this.ActRoute.snapshot.queryParams['returnUrl'] || '/admin/';
    this.urlAssociation = this.ActRoute.snapshot.queryParams['returnUrl'] || '/association/';

    if (this.authadmin.AdminisLoggedIN() == true) {
      this.router.navigate(['/admin']);
    }

    if (this.authadmin.AssociationisLoggedIN() == true) {
      this.router.navigate(['/association']);
    }
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  loginadmin(f: any) {
    let data = f.value;
    this.authadmin.Lougout();
    this.authadmin.login(data).subscribe(
      (response) => {
        this.dataRecevie = response;

        if (this.dataRecevie.roles == 'ROLE_ADMIN') {
          this.authadmin.SaveDataProfile(this.dataRecevie);
          this.router.navigate([this.urlAdmin]);
        } else if (this.dataRecevie.roles == 'ROLE_ASSOCIATION') {
          this.authadmin.SaveDataProfile(this.dataRecevie);
          this.router.navigate([this.urlAssociation]);
        } else {
          this.notifyService.showError('Error', 'sqdsqdqsdsqdsqdsqdqsd');
        }
      },
      (error: HttpErrorResponse) => {
        Swal.fire('Désolé', error.error.message, 'error');
      }
    );
  }
}
