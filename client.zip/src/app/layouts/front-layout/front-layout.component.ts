import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { UUID } from 'angular2-uuid';
@Component({
  selector: 'app-front-layout',
  templateUrl: './front-layout.component.html',
  styleUrls: ['./front-layout.component.css'],
})
export class FrontLayoutComponent implements OnInit {
  uuidValue: string = '';
  checkingbox: boolean = false;
  constructor(
    public authadmin: AuthserviceService,
    private cookieService: CookieService
  ) {}

  ngOnInit(): void {
    this.Check();
  }

  generateUUID() {
    this.uuidValue = UUID.UUID();
    return this.uuidValue;
  }

  Check() {
    const analytics = this.cookieService.check(
      'cookielawinfo-checkbox-analytics'
    );
    const advertisement = this.cookieService.check(
      'cookielawinfo-checkbox-advertisement'
    );
    const necessary = this.cookieService.check(
      'cookielawinfo-checkbox-necessary'
    );
    const others = this.cookieService.check('cookielawinfo-checkbox-others');
    const functional = this.cookieService.check(
      'cookielawinfo-checkbox-functional'
    );
    const viewed_cookie_policy = this.cookieService.check(
      'viewed_cookie_policy'
    );
    const performance = this.cookieService.check(
      'cookielawinfo-checkbox-performance'
    );
    const CookieLawInfoConsent = this.cookieService.check(
      'CookieLawInfoConsent'
    );

    if (
      analytics &&
      advertisement &&
      necessary &&
      others &&
      functional &&
      viewed_cookie_policy &&
      performance &&
      CookieLawInfoConsent
    ) {
      this.checkingbox = false;
    } else {
      this.checkingbox = true;
    }
  }

  Allow() {
    this.cookieService.set('cookielawinfo-checkbox-analytics', 'no', {
      expires: 365,
    });
    this.cookieService.set('cookielawinfo-checkbox-advertisement', 'no', {
      expires: 365,
    });
    this.cookieService.set('cookielawinfo-checkbox-necessary', 'yes', {
      expires: 365,
    });
    this.cookieService.set('cookielawinfo-checkbox-others', 'no', {
      expires: 365,
    });
    this.cookieService.set('cookielawinfo-checkbox-functional', 'no', {
      expires: 365,
    });
    this.cookieService.set('viewed_cookie_policy', 'yes', { expires: 365 });
    this.cookieService.set('cookielawinfo-checkbox-performance', 'no', {
      expires: 365,
    });
    this.cookieService.set('CookieLawInfoConsent', this.generateUUID(), {
      expires: 365,
    });

    this.checkingbox = false;
  }

  Decline() {
    this.checkingbox = false;
  }

  LogOut() {
    window.location.reload();
    localStorage.clear();
  }
}
