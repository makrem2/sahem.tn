import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-association-layout',
  templateUrl: './association-layout.component.html',
  styleUrls: ['./association-layout.component.css']
})
export class AssociationLayoutComponent implements OnInit {

  Userid:any
  imagepath:any=environment.imgUrl
  UserData:any
  constructor(private authadmin: AuthserviceService,
    private route: Router,
    private userservice:UserServiceService) { }

    ngOnInit(): void {

      this.Userid = this.authadmin.getUserid()
   
       this.userservice.getOneUser(this.Userid).subscribe((data)=>{
   
         this.UserData=data
   
       },
       (err: HttpErrorResponse) => {
   
         console.log(err)
       });
   
     }
     
   
     Lougout() {
       this.authadmin.Lougout();
       this.route.navigate(['/login']);
     }
   
   }
   
