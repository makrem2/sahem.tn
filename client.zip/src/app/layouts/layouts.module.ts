import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { FrontLayoutComponent } from './front-layout/front-layout.component';
import { RouterModule, RouterOutlet } from '@angular/router';
import { AssociationLayoutComponent } from './association-layout/association-layout.component';
import { LoginLayoutComponent } from './login-layout/login-layout.component';
import { Pages404ComponentComponent } from './pages404-component/pages404-component.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AdminLayoutComponent,
    FrontLayoutComponent,
    AssociationLayoutComponent,
    LoginLayoutComponent,
    Pages404ComponentComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ]
})
export class LayoutsModule { }
