import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages404-component',
  templateUrl: './pages404-component.component.html',
  styleUrls: ['./pages404-component.component.css']
})
export class Pages404ComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
