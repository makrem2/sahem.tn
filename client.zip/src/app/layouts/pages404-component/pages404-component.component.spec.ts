import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pages404ComponentComponent } from './pages404-component.component';

describe('Pages404ComponentComponent', () => {
  let component: Pages404ComponentComponent;
  let fixture: ComponentFixture<Pages404ComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Pages404ComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Pages404ComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
