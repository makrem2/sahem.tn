import { TestBed } from '@angular/core/testing';

import { GuardsUserGuard } from './guards-user.guard';

describe('GuardsUserGuard', () => {
  let guard: GuardsUserGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(GuardsUserGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
