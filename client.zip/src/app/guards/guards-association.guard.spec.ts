import { TestBed } from '@angular/core/testing';

import { GuardsAssociationGuard } from './guards-association.guard';

describe('GuardsAssociationGuard', () => {
  let guard: GuardsAssociationGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(GuardsAssociationGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
