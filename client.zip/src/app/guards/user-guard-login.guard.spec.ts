import { TestBed } from '@angular/core/testing';

import { UserGuardLoginGuard } from './user-guard-login.guard';

describe('UserGuardLoginGuard', () => {
  let guard: UserGuardLoginGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(UserGuardLoginGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
