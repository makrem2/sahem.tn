import { TestBed } from '@angular/core/testing';

import { UsernoGuardGuard } from './userno-guard.guard';

describe('UsernoGuardGuard', () => {
  let guard: UsernoGuardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(UsernoGuardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
