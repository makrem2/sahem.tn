import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GuardsAssociationGuard } from './guards/guards-association.guard';
import { GuardsadminGuard } from './guards/guardsadmin.guard';
import { UserGuardLoginGuard } from './guards/user-guard-login.guard';
import { UsernoGuardGuard } from './guards/userno-guard.guard';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { AssociationLayoutComponent } from './layouts/association-layout/association-layout.component';
import { FrontLayoutComponent } from './layouts/front-layout/front-layout.component';
import { LoginLayoutComponent } from './layouts/login-layout/login-layout.component';
import { Pages404ComponentComponent } from './layouts/pages404-component/pages404-component.component';

const routes: Routes = [
  {path:'',component:FrontLayoutComponent,children:[{
    path:'',loadChildren:()=>import('./views/front/home/home.module').then(m=>m.HomeModule)},
    {path:'about',loadChildren:()=>import('./views/front/about/about.module').then(m=>m.AboutModule)},
    {path:'contact',loadChildren:()=>import('./views/front/contact/contact.module').then(m=>m.ContactModule)},
    {path:'evenement',loadChildren:()=>import('./views/front/evenement/evenement.module').then(m=>m.EvenementModule)},
    {path:'mes-dons',loadChildren:()=>import('./views/front/mes-dons/mes-dons.module').then(m=>m.MesDonsModule),
    canActivateChild:[UsernoGuardGuard]},
    {path:'mes-besoin',loadChildren:()=>import('./views/front/mes-besoin/mes-besoin.module').then(m=>m.MesBesoinModule),
    canActivateChild:[UsernoGuardGuard]},
    {path:'moncompte',loadChildren:()=>import('./views/front/moncompte/moncompte.module').then(m=>m.MoncompteModule),
    canActivateChild:[UsernoGuardGuard]},
    {path:'FaireDon',loadChildren:()=>import('./views/front/faire-don/faire-don.module').then(m=>m.FaireDonModule),
    canActivateChild:[UsernoGuardGuard]},
    {path:'registre',loadChildren:()=>import('./views/front/registre/registre.module').then(m=>m.RegistreModule),
    canActivateChild:[UserGuardLoginGuard]},
    {path:'loginuser',loadChildren:()=>import('./views/front/loginuser/loginuser.module').then(m=>m.LoginuserModule),
    canActivateChild:[UserGuardLoginGuard]},
    {path:'blog',loadChildren:()=>import('./views/front/blog/blog.module').then(m=>m.BlogModule)},
    {path:'beneficier',loadChildren:()=>import('./views/front/besoin/besoin.module').then(m=>m.BesoinModule),
    canActivateChild:[UsernoGuardGuard]},
    {path:'detail-blog',loadChildren:()=>import('./views/front/detail-blog/detail-blog.module').then(m=>m.DetailBlogModule)},
    {path:'detail-compagne',loadChildren:()=>import('./views/front/detail-compagne/detail-compagne.module').then(m=>m.DetailCompagneModule)},
    {path:'detail-event',loadChildren:()=>import('./views/front/detail-event/detail-event.module').then(m=>m.DetailEventModule)}
  
  ]},
  {path:'admin',component:AdminLayoutComponent,canActivate:[GuardsadminGuard],children:[
    {path:'',loadChildren:()=>import('./views/admin/dashboard/dashboard.module').then(m=>m.DashboardModule)},
    {path:'dashboard',loadChildren:()=>import('./views/admin/dashboard/dashboard.module').then(m=>m.DashboardModule)},
    {path:'userprofile',loadChildren:()=>import('./views/admin/user-profile/user-profile.module').then(m=>m.UserProfileModule)},
    {path:'Gestion-Equipe',loadChildren:()=>import('./views/admin/gestion-equipe/gestion-equipe.module').then(m=>m.GestionEquipeModule)},
    {path:'Gestion-Utilisateurs',loadChildren:()=>import('./views/admin/gestion-utilisateurs/gestion-utilisateurs.module').then(m=>m.GestionUtilisateursModule)},
    {path:'Gestion-Fournitures-Categories',loadChildren:()=>import('./views/admin/gestion-categories/gestion-categories.module').then(m=>m.GestionCategoriesModule)},
    {path:'Gestion-Event',loadChildren:()=>import('./views/admin/gestion-event/gestion-event.module').then(m=>m.GestionEventModule)},
    {path:'Gestion-Blog',loadChildren:()=>import('./views/admin/gestion-blog/gestion-blog.module').then(m=>m.GestionBlogModule)},
    {path:'Gestion-Report',loadChildren:()=>import('./views/admin/gestion-report/gestion-report.module').then(m=>m.GestionReportModule)},
    {path:'Gestion-Contact',loadChildren:()=>import('./views/admin/gestion-contact/gestion-contact.module').then(m=>m.GestionContactModule)},
    {path:'Gestion-Compagne',loadChildren:()=>import('./views/admin/gestion-compagne/gestion-compagne.module').then(m=>m.GestionCompagneModule)},
    {path:'Gestion-Partenaire',loadChildren:()=>import('./views/admin/gestion-partenaire/gestion-partenaire.module').then(m=>m.GestionPartenaireModule)},
    {path:'Gestion-Fourniture-Don',loadChildren:()=>import('./views/admin/gestion-fourniture-don/gestion-fourniture-don.module').then(m=>m.GestionFournitureDonModule)}
  ]},

  {path:'association',component:AssociationLayoutComponent,canActivate:[GuardsAssociationGuard],children:[
    {path:'',loadChildren:()=>import('./views/association/dashboard/dashboard.module').then(m=>m.DashboardModule)},
    {path:'dashboard-association',loadChildren:()=>import('./views/association/dashboard/dashboard.module').then(m=>m.DashboardModule)},
    {path:'userprofile',loadChildren:()=>import('./views/association/user-profile/user-profile.module').then(m=>m.UserProfileModule)},
    {path:'Gestion-Event',loadChildren:()=>import('./views/association/gestion-event/gestion-event.module').then(m=>m.GestionEventModule)},
    {path:'Gestion-Blog',loadChildren:()=>import('./views/association/gestion-blog/gestion-blog.module').then(m=>m.GestionBlogModule)},
    {path:'Gestion-Compagne',loadChildren:()=>import('./views/association/gestion-compagne/gestion-compagne.module').then(m=>m.GestionCompagneModule)},
    {path:'dons',loadChildren:()=>import('./views/association/dons/dons.module').then(m=>m.DonsModule)},
    {path:'besion',loadChildren:()=>import('./views/association/besion/besion.module').then(m=>m.BesionModule)},
    {path:'donateur',loadChildren:()=>import('./views/association/donateur/donateur.module').then(m=>m.DonateurModule)},
  ]},

  {path:'login',component:LoginLayoutComponent},

  {path:'**',component:Pages404ComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
