import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DonateurComponent } from './donateur/donateur.component';

const routes: Routes = [
  {path:'',component:DonateurComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DonateurRoutingModule { }
