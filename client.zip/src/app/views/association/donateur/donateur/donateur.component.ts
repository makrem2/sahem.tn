import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-donateur',
  templateUrl: './donateur.component.html',
  styleUrls: ['./donateur.component.css'],
})
export class DonateurComponent implements OnInit {
  p: number = 1;
  searchText: any;
  Userid: any;
  DataUser: any;
  listDonateur:any
  imagepath: any = environment.imgUrl;
  constructor(
    private UserServiceService: UserServiceService,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.Userid = this.authadmin.getUserid();

    this.UserServiceService.getOneUser(this.Userid).subscribe(
      (data) => {
        this.DataUser = data;
        this.UserServiceService.getAlluserByRoleANDAdress(
          'user',this.DataUser.ville
        ).subscribe(
          (data) => {

            this.listDonateur=data
          },
          (err: HttpErrorResponse) => {}
        );
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
    // this.UserServiceService.getAllUserByRegion()
  }
}
