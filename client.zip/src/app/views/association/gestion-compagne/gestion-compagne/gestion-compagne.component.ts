import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import Swal from 'sweetalert2';

import { AuthserviceService } from 'src/app/services/authservice.service';
import { environment } from 'src/environments/environment';
import { CompagneService } from 'src/app/services/compagne.service';
@Component({
  selector: 'app-gestion-compagne',
  templateUrl: './gestion-compagne.component.html',
  styleUrls: ['./gestion-compagne.component.css'],
})
export class GestionCompagneComponent implements OnInit {
  p: number = 1;
  searchText: any;
  DataCompagne: any;
  idCompagne: any;
  CompagneData = {
    id: 0,
    sous_desc:'',
    title: '',
    desc: '',
  };
  formdata: any;
  formdataa: any;
  images: any;
  Userid: any;
  imagepath: any = environment.imgUrl;
  constructor(
    private CompagneService: CompagneService,
    private formBuilder: FormBuilder,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.Userid = this.authadmin.getUserid();
    this.GetAllCompagne();
    this.formdata = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      sous_desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
    this.formdataa = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      sous_desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const path = event.target.files[0];
      console.log(path);
      this.images = path;
    }
  }

  GetAllCompagne() {
    this.CompagneService.getAllUserCompagne(this.Userid).subscribe(
      (data) => {
        this.DataCompagne = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  AddCompagne(f: any) {
    const formData = new FormData();

    formData.append('title', f.title);
    formData.append('sous_desc', f.sous_desc);
    formData.append('desc', f.desc);
    formData.append('photo', this.images);
    formData.append('userId', this.Userid);

    this.CompagneService.addCompagne(formData).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Compagne enregistré avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec denregistré cet Compagne ! :)', 'error');
      }
    );
  }

  getitemtomodifier(id: any, title: any, desc: any,sous_desc:any) {
    this.CompagneData.id = id;
    this.CompagneData.title = title;
    this.CompagneData.desc = desc;
    this.CompagneData.sous_desc=sous_desc

    console.log(this.CompagneData)
  }

  GetIdToDelete(id: any) {
    this.idCompagne = id;
  }

  updateCompagne(f: any) {

    this.CompagneService.updateCompagne(this.CompagneData.id, f).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Compagne modifié avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  DeleteCompagne() {
    this.CompagneService.deletecompagne(this.idCompagne).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Compagne supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
