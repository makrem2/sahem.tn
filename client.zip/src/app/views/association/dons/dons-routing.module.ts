import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DonsComponent } from './dons/dons.component';

const routes: Routes = [
  {path:'',component:DonsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DonsRoutingModule { }
