import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { FournitureDonService } from 'src/app/services/fourniture-don.service';
import { ReportService } from 'src/app/services/report.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-dons',
  templateUrl: './dons.component.html',
  styleUrls: ['./dons.component.css'],
})
export class DonsComponent implements OnInit {
  pDon: number = 1;
  pFourniture: number = 1;
  searchDon: any;
  searchFourniture: any;
  DataDon: any;
  DataFourniture: any;
  IdDon: any;
  idFourniture: any;
  DataUser: any;
  UserId: any;
  images: any;
  imagepath: any = environment.imgUrl;
  etat={
    etat:''
  }
  DataDonateur:any
  constructor(
    private FournitureDonService: FournitureDonService,
    private authadmin: AuthserviceService,
    private userservice: UserServiceService,
    private reportService:ReportService
  ) {}

  ngOnInit(): void {
    this.UserId = this.authadmin.getUserid();
    this.getAllDon();
  }
  getAllDon() {
    this.userservice.getOneUser(this.UserId).subscribe((data) => {
      this.DataUser = data;
      this.FournitureDonService.getDonByRegion(this.DataUser.ville).subscribe(
        (data) => {
          this.DataDon = data;
        },
        (err: HttpErrorResponse) => {
          this.ngOnInit();
          Swal.fire('Désolé', err.error.message, 'error');
        }
      );
    });
  }

  getIDDon(id: any) {
    this.IdDon = id;
    this.FournitureDonService.getAllFournitureBydonId(id).subscribe(
      (data) => {
        this.DataFourniture = data;
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  GetIdToUpdateEtat(id: any) {
    this.IdDon = id;
  }



  UpdateEtat(up: any) {

    this.etat.etat=up.value.etat
    
    this.FournitureDonService.validerledon(this.IdDon,this.etat).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Etat modifié avec succès! ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }


  VoirUser(iduser:any){    

    this.userservice.getOneUser(iduser).subscribe((data)=>{
      this.DataDonateur=data
    })
  }


  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const photo = event.target.files[0];
      this.images = photo;
    }
  }

  Report(f:any){

  const formData = new FormData();

    formData.append('desc',f.value.desc);
    formData.append('photo', this.images);
    formData.append('donId', this.IdDon);
    formData.append('userId', this.UserId);

    this.reportService.addReport(formData).subscribe((data)=>{
      Swal.fire(
        'Thank you...',
        'Report enregistré avec succès: ',
        'success'
      );
    },(error:HttpErrorResponse)=>{
      Swal.fire('Désolé', 'Échec denregistré cet Report ! :)', 'error');

    })


  }
}
