import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
})
export class UserProfileComponent implements OnInit {
  Userid: any;
  imagepath: any = environment.imgUrl;
  UserData: any;
  images: any;
  messageSuccess: any;
  messageError: any;
  visible: boolean = true;
  changetype: boolean = true;
  ville: any = [
    { id: 1, nom: 'Ariana' },
    { id: 2, nom: 'beja' },
    { id: 3, nom: 'Ben Arous' },
    { id: 4, nom: 'Bizerte' },
    { id: 5, nom: 'Gabés' },
    { id: 6, nom: 'Jendouba' },
    { id: 7, nom: 'kairouan' },
    { id: 8, nom: 'Gafsa' },
    { id: 9, nom: 'Kasserine' },
    { id: 10, nom: 'Kebili ' },
    { id: 11, nom: 'kef' },
    { id: 12, nom: 'Mahdia' },
    { id: 13, nom: 'Manouba' },
    { id: 14, nom: 'Medenine' },
    { id: 15, nom: 'Monastir' },
    { id: 16, nom: 'Nabeul' },
    { id: 17, nom: 'Sfax' },
    { id: 18, nom: 'Sidi Bouzid' },
    { id: 19, nom: 'Siliana' },
    { id: 20, nom: 'Sousse' },
    { id: 21, nom: 'Tataouine' },
    { id: 22, nom: 'Tozeur' },
    { id: 23, nom: 'Tunis' },
    { id: 24, nom: 'Zaghouan' },
  ];
  constructor(
    private userservice: UserServiceService,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.Userid = this.authadmin.getUserid();

    this.userservice.getOneUser(this.Userid).subscribe(
      (data) => {
        this.UserData = data;

        console.log(this.UserData)
      },
      (err: HttpErrorResponse) => {
        console.log(err);
      }
    );
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const photo = event.target.files[0];
      this.images = photo;
    }
  }

  updatephoto() {
    let body = new FormData();
    body.append('photo', this.images);
    this.userservice.updateUserImage(this.Userid, body).subscribe(
      (response) => {
        this.ngOnInit();
       
        Swal.fire('Thank you...', 'Photo modifié avec succès! ', 'success');

        window.location.reload();
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  UpdateProfile(up: any) {
    let data = up.value;
    this.userservice.updateUser(this.Userid, data).subscribe(
      (response) => {
        this.ngOnInit();
        Swal.fire(
          'Thank you...',
          'User Information modifié avec succès! ',
          'success'
        );
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }
}
