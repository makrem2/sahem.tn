import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { BesoinService } from 'src/app/services/besoin.service';
import { ReportService } from 'src/app/services/report.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-besion',
  templateUrl: './besion.component.html',
  styleUrls: ['./besion.component.css'],
})
export class BesionComponent implements OnInit {
  pbesion: number = 1;
  searchbesion: any;
  Databesion: any;
  Idbesion: any;
  idDonateur: any;
  DataUser: any;
  DataDonateur:any;
  UserId: any;
  imagepath: any = environment.imgUrl;
  detail:any
  images:any;
  besoinn:any
  etat={
    etat:''
  }
  constructor(
    private besionservice: BesoinService,
    private authadmin: AuthserviceService,
    private userservice: UserServiceService,
    private reportService:ReportService
  ) {}

  ngOnInit(): void {
    this.UserId = this.authadmin.getUserid();
    this.getAllBesionBYAdress();
  }

  getdetailBesoin(detail: any, besoin: any) {
    this.detail = detail;

    this.besoinn = besoin;
  }

  getAllBesionBYAdress() {
    this.userservice.getOneUser(this.UserId).subscribe((data) => {
      this.DataUser = data;
      this.besionservice.getAllBesionBYAdress(this.DataUser.ville).subscribe(
        (data) => {
          this.Databesion = data;
        },
        (err: HttpErrorResponse) => {
          Swal.fire('Désolé', err.error.message, 'error');
        }
      );
    });
  }

  GetIdToUpdateEtat(id:any){
    this.Idbesion=id
  }

  VoirUser(iduser:any){    

    this.userservice.getOneUser(iduser).subscribe((data)=>{
      this.DataDonateur=data
    })
  }

  UpdateEtat(up: any) {

    this.etat.etat=up.value.etat
    
    this.besionservice.updateEtat(this.Idbesion,this.etat).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Etat modifié avec succès! ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }



  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const photo = event.target.files[0];
      this.images = photo;
    }
  }

  Report(f:any){

    const formData = new FormData();
  
      formData.append('desc',f.value.desc);
      formData.append('photo', this.images);
      formData.append('besoinId', this.Idbesion);
      formData.append('userId', this.UserId);
  
      this.reportService.addReportBesoin(formData).subscribe((data)=>{
        Swal.fire(
          'Thank you...',
          'Report enregistré avec succès: ',
          'success'
        );
      },(error:HttpErrorResponse)=>{
        Swal.fire('Désolé', 'Échec denregistré cet Report ! :)', 'error');
  
      })
  
  
    }
}
