import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BesionComponent } from './besion.component';

describe('BesionComponent', () => {
  let component: BesionComponent;
  let fixture: ComponentFixture<BesionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BesionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BesionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
