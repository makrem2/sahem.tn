import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BesionRoutingModule } from './besion-routing.module';
import { BesionComponent } from './besion/besion.component';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SafeHtmlPipe } from './besion/safe-html.pipe';


@NgModule({
  declarations: [
    BesionComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    BesionRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule
  ]
})
export class BesionModule { }
