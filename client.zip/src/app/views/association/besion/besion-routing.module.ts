import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BesionComponent } from './besion/besion.component';

const routes: Routes = [
  {path:'',component:BesionComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BesionRoutingModule { }
