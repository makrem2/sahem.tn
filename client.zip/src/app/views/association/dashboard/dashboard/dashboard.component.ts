import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { BesoinService } from 'src/app/services/besoin.service';
import { FournitureDonService } from 'src/app/services/fourniture-don.service';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  nbdonEnAttend: any;
  nbDonLivree: any;

  nbbesionEnAttend: any;
  nbbesionLivree: any;

  userid: any;
  DataUser: any;
  constructor(
    private donservice: FournitureDonService,
    private besionservice: BesoinService,
    private userserivce: UserServiceService,
    private authservice: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.userid = this.authservice.getUserid();

    this.getnbbesionEnAttend();
    this.getnbbesionLivree();
    this.getnbdonEnAttend();
    this.getnbDonLivree();
  }

  getnbbesionEnAttend() {
    this.userserivce.getOneUser(this.userid).subscribe((data) => {
      this.DataUser = data;

      this.besionservice
        .getAllAssociationBesionBYEtat('EnAttende', this.DataUser.ville)
        .subscribe((data) => {
          this.nbbesionEnAttend = data;
        });
    });
  }

  getnbbesionLivree() {
    this.userserivce.getOneUser(this.userid).subscribe((data) => {
      this.DataUser = data;
      this.besionservice
        .getAllAssociationBesionBYEtat('livrée', this.DataUser.ville)
        .subscribe((data) => {
          this.nbbesionLivree = data;
        });
    });
  }

  getnbdonEnAttend() {
    this.userserivce.getOneUser(this.userid).subscribe((data) => {
      this.DataUser = data;
      console.log('hellooooooooooooooooo',this.DataUser.ville)
      this.donservice
        .getAllAssociationDonBYEtat('EnAttende', this.DataUser.ville)
        .subscribe((data) => {
          this.nbdonEnAttend = data;
          console.log(this.nbdonEnAttend)
        });
    });
  }
  getnbDonLivree() {
    this.userserivce.getOneUser(this.userid).subscribe((data) => {
      this.DataUser = data;
      this.donservice
        .getAllAssociationDonBYEtat('livrée', this.DataUser.ville)
        .subscribe((data) => {
          this.nbDonLivree = data;
        });
    });
  }
}
