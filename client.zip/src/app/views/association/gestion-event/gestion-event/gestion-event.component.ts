import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { environment } from 'src/environments/environment';



import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-event',
  templateUrl: './gestion-event.component.html',
  styleUrls: ['./gestion-event.component.css'],
})
export class GestionEventComponent implements OnInit {
  p: number = 1;
  searchText: any;
  DataEvent: any;
  idEvent: any;
  EventData = {
    id: 0,
    title: '',
    desc: '',
  };
  formdata: any;
  formdataa: any;
  images: any;
  Userid: any;
  imagepath: any = environment.imgUrl;
  constructor(
    private EventBlogService: EventBlogService,
    private formBuilder: FormBuilder,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.GetAllEvent();
    this.Userid = this.authadmin.getUserid();
    this.formdata = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
    this.formdataa = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const path = event.target.files[0];
      console.log(path);
      this.images = path;
    }
  }

  GetAllEvent() {

    this.Userid = this.authadmin.getUserid();
    this.EventBlogService.getAllUserEvent(this.Userid).subscribe(
      (data) => {
        this.DataEvent = data;
        console.log(this.DataEvent)
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  AddEvent(f: any) {
    const formData = new FormData();

    formData.append('title', f.title);
    formData.append('desc', f.desc);
    formData.append('photo', this.images);
    formData.append('userId', this.Userid);

    this.EventBlogService.addEvent(formData).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Event enregistré avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec denregistré cet Event ! :)', 'error');
      }
    );
  }

  getitemtomodifier(id: any, title: any, desc: any) {
    this.EventData.id = id;
    this.EventData.title = title;
    this.EventData.desc = desc;
  }

  GetIdToDelete(id: any) {
    this.idEvent = id;
  }

  updateEvent(f: any) {
    this.EventBlogService.updateEvent(this.EventData.id, f).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Event modifié avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  DeleteEvent() {
    this.EventBlogService.deleteEvent(this.idEvent).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Event supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
