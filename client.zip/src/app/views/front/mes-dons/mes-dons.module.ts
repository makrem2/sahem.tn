import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MesDonsRoutingModule } from './mes-dons-routing.module';
import { MesDonsComponent } from './mes-dons/mes-dons.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    MesDonsComponent
  ],
  imports: [
    CommonModule,
    MesDonsRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule
  ]
})
export class MesDonsModule { }
