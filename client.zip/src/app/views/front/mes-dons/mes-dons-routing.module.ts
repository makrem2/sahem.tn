import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MesDonsComponent } from './mes-dons/mes-dons.component';

const routes: Routes = [
  {path:'',component:MesDonsComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MesDonsRoutingModule { }
