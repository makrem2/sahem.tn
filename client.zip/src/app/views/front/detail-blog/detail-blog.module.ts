import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DetailBlogRoutingModule } from './detail-blog-routing.module';
import { DetailBlogComponent } from './detail-blog/detail-blog.component';
import { SafeHtmlPipe } from './detail-blog/safe-html.pipe';


@NgModule({
  declarations: [
    DetailBlogComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    DetailBlogRoutingModule
  ]
})
export class DetailBlogModule { }
