import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-detail-blog',
  templateUrl: './detail-blog.component.html',
  styleUrls: ['./detail-blog.component.css']
})
export class DetailBlogComponent implements OnInit {

  idblog:any
  DataBlog:any
  imagepath: any = environment.imgUrl;
  constructor(private ds: EventBlogService,
    private Activatedroute: ActivatedRoute) { 
      this.idblog = this.Activatedroute.snapshot.queryParamMap.get('blogid') || 0;
    }

  ngOnInit(): void {

    this.ds.getOneBlog(this.idblog).subscribe((data)=>{

      this.DataBlog=data

    },
    (error:HttpErrorResponse)=>{


    });


  }

}
