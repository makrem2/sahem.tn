import { Component, OnInit } from '@angular/core';
import { ContactService } from 'src/app/services/contact.service';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private contact:ContactService) { }

  ngOnInit(): void {

    
  }


  addContact(f:any){
    console.log(f.value); 

    this.contact.addContact(f.value).subscribe((data)=>{
      Swal.fire('Thank you...', 'Vos Message a été soumises avec succès. Merci !', 'success');
    },(error:HttpErrorResponse)=>{

      Swal.fire('Désolé', 'Échec dEnvoyer Votre Message ! :)', 'error');

    })
  }

}
