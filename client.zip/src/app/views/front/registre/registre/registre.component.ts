import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import Swal from 'sweetalert2';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-registre',
  templateUrl: './registre.component.html',
  styleUrls: ['./registre.component.css'],
})
export class RegistreComponent implements OnInit {
  formdata: any;
  messagesucces:any
  messageerror:any
  visible: boolean = true;
  changetype: boolean = true;
  DataUser={
    username:'',
    email:'',
    password:'',
    role:''
  }
  constructor(
    private formBuilder: FormBuilder,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.formdata = this.formBuilder.group({
      username: [
        '',
        [
          Validators.required,
          Validators.maxLength(20),
          Validators.minLength(3),
        ],
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.maxLength(100),
          Validators.minLength(8),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.maxLength(25),
          Validators.minLength(8),
        ],
      ],
    });
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  register(data:any){

    this.DataUser.username=data.username
    this.DataUser.email=data.email
    this.DataUser.password=data.password
    this.DataUser.role='user'


    console.log(this.DataUser)

    this.authadmin.register(this.DataUser).subscribe((data)=>{
      this.messagesucces=data
      Swal.fire('Thank you...', this.messagesucces, 'success');
    },
    (error:HttpErrorResponse)=>{
      this.messageerror=error.error.message;
      Swal.fire('Désolé', this.messageerror, 'error');
    })




  }
}
