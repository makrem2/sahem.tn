import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DetailCompagneRoutingModule } from './detail-compagne-routing.module';
import { DetailCompagneComponent } from './detail-compagne/detail-compagne.component';
import { SafeHtmlPipe } from './detail-compagne/safe-html.pipe';


@NgModule({
  declarations: [
    DetailCompagneComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    DetailCompagneRoutingModule
  ]
})
export class DetailCompagneModule { }
