import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompagneService } from 'src/app/services/compagne.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-detail-compagne',
  templateUrl: './detail-compagne.component.html',
  styleUrls: ['./detail-compagne.component.css'],
})
export class DetailCompagneComponent implements OnInit {
  idcompagne: any;
  DataCompagne: any;
  imagepath: any = environment.imgUrl;
  constructor(
    private Activatedroute: ActivatedRoute,
    private ds: CompagneService
  ) {
    this.idcompagne =
      this.Activatedroute.snapshot.queryParamMap.get('compagneid') || 0;
  }

  ngOnInit(): void {
    this.ds.getOneCompagne(this.idcompagne).subscribe(
      (data) => {
        this.DataCompagne = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }
}
