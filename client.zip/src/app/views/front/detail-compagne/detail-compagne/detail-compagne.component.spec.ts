import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailCompagneComponent } from './detail-compagne.component';

describe('DetailCompagneComponent', () => {
  let component: DetailCompagneComponent;
  let fixture: ComponentFixture<DetailCompagneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailCompagneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailCompagneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
