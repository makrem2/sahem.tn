import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailCompagneComponent } from './detail-compagne/detail-compagne.component';

const routes: Routes = [
  {path:'',component:DetailCompagneComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DetailCompagneRoutingModule { }
