import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { SafeHtmlPipe } from './home/safe-html.pipe';
import { NextDirective } from './home/next.directive';
import { PrevDirective } from './home/prev.directive';


@NgModule({
  declarations: [
    HomeComponent,
    SafeHtmlPipe,
    NextDirective,
    PrevDirective
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule
  ]
})
export class HomeModule { }
