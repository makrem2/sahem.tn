import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { CompagneService } from 'src/app/services/compagne.service';
import { EquipeService } from 'src/app/services/equipe.service';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { PartenaireService } from 'src/app/services/partenaire.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  pblog: number = 1;
  pevent: number = 1;
  pcompagne: number = 1;
  DataCompagne: any;
  DataBlog: any;
  DataPartenaire: any;
  DataEvent: any;
  imagepath: any = environment.imgUrl;
  DataEquipe: any;
  responsiveOptions: any;
  constructor(
    private EventBlogService: EventBlogService,
    private router: Router,
    private CompagneService: CompagneService,
    private equipeservice: EquipeService,
    private partenaireservice: PartenaireService
  ) {
    this.responsiveOptions = [
      {
        breakpoint: '1024px',
        numVisible: 3,
        numScroll: 3,
      },
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2,
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1,
      },
    ];
  }

  ngOnInit(): void {
    this.GetAllEvent();
    this.GetAllBlog();
    this.GetAllCompagne();
    this.getAllEquipe();
    this.getAllPartenaire();
  }

  getAllPartenaire() {
    this.partenaireservice.getAllPartenaire().subscribe(
      (data) => {
        this.DataPartenaire = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }

  getAllEquipe() {
    this.equipeservice.getAllEquipe().subscribe(
      (data) => {
        this.DataEquipe = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }

  GetAllCompagne() {
    this.CompagneService.getAllCompagnes().subscribe(
      (data) => {
        this.DataCompagne = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  GetAllBlog() {
    this.EventBlogService.getAllBlog().subscribe(
      (data) => {
        this.DataBlog = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  GetAllEvent() {
    this.EventBlogService.getAllEvent().subscribe(
      (data) => {
        this.DataEvent = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  sendIDCompagne(id: any) {
    this.router.navigate(['/detail-compagne'], {
      queryParams: { compagneid: id },
    });
  }

  sendIDEvent(id: any) {
    this.router.navigate(['/detail-event'], { queryParams: { eventid: id } });
  }

  sendIDBlog(id: any) {
    this.router.navigate(['/detail-blog'], { queryParams: { blogid: id } });
  }
}
