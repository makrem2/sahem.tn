import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  pblog: number = 1;
  DataBlog:any;
  imagepath: any = environment.imgUrl;
  constructor(private EventBlogService: EventBlogService,
    private authadmin: AuthserviceService,
    private router:Router) { }

  ngOnInit(): void {
    this.GetAllBlog();
  }

  GetAllBlog() {
    this.EventBlogService.getAllBlog().subscribe(
      (data) => {
        this.DataBlog = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  sendIDBlog(id:any){

    this.router.navigate(['/detail-blog'], { queryParams: { blogid: id } }); 

  }

}
