import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DetailEventRoutingModule } from './detail-event-routing.module';
import { DetailEventComponent } from './detail-event/detail-event.component';
import { SafeHtmlPipe } from './detail-event/safe-html.pipe';


@NgModule({
  declarations: [
    DetailEventComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    DetailEventRoutingModule
  ]
})
export class DetailEventModule { }
