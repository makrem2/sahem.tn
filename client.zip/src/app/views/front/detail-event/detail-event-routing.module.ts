import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailEventComponent } from './detail-event/detail-event.component';

const routes: Routes = [
  {path:'',component:DetailEventComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DetailEventRoutingModule { }
