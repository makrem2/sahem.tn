import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FaireDonRoutingModule } from './faire-don-routing.module';
import { FaireDonComponent } from './faire-don/faire-don.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    FaireDonComponent
  ],
  imports: [
    CommonModule,
    FaireDonRoutingModule,
    FormsModule
  ]
})
export class FaireDonModule { }
