import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FaireDonComponent } from './faire-don/faire-don.component';

const routes: Routes = [
  {path:'',component:FaireDonComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FaireDonRoutingModule { }
