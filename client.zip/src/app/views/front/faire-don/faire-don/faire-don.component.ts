import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { CategoriefournitureService } from 'src/app/services/categoriefourniture.service';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { FournitureDonService } from 'src/app/services/fourniture-don.service';
import { UUID } from 'angular2-uuid';
import Swal from 'sweetalert2';
import { UserServiceService } from 'src/app/services/user-service.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-faire-don',
  templateUrl: './faire-don.component.html',
  styleUrls: ['./faire-don.component.css'],
})
export class FaireDonComponent implements OnInit {
  steps: any = 1;
  dataDon = {
    userId: '',
    username: '',
    adresse: '',
    code: '',
  };
  donID: any;
  uuidValue: string = '';
  userid: any;
  DataUser: any;
  DataCategorie: any;
  DataFourniture: any;
  ville: any = [
    { id: 1, nom: 'Ariana' },
    { id: 2, nom: 'beja' },
    { id: 3, nom: 'Ben Arous' },
    { id: 4, nom: 'Bizerte' },
    { id: 5, nom: 'Gabés' },
    { id: 6, nom: 'Jendouba' },
    { id: 7, nom: 'kairouan' },
    { id: 8, nom: 'Gafsa' },
    { id: 9, nom: 'Kasserine' },
    { id: 10, nom: 'Kebili ' },
    { id: 11, nom: 'kef' },
    { id: 12, nom: 'Mahdia' },
    { id: 13, nom: 'Manouba' },
    { id: 14, nom: 'Medenine' },
    { id: 15, nom: 'Monastir' },
    { id: 16, nom: 'Nabeul' },
    { id: 17, nom: 'Sfax' },
    { id: 18, nom: 'Sidi Bouzid' },
    { id: 19, nom: 'Siliana' },
    { id: 20, nom: 'Sousse' },
    { id: 21, nom: 'Tataouine' },
    { id: 22, nom: 'Tozeur' },
    { id: 23, nom: 'Tunis' },
    { id: 24, nom: 'Zaghouan' },
  ];
  dataFourniture = {
    nombre: '',
    Sexe: '',
    couleur: '',
    niveau: '',
    categoryId: '',
    donId: '',
    typeFournitureId: '',
  };
  constructor(
    private authadmin: AuthserviceService,
    private route: Router,
    private categorie_type: CategoriefournitureService,
    private router: Router,
    private eventBlog: EventBlogService,
    private fournitureDon: FournitureDonService,
    private userserivce: UserServiceService
  ) {}

  ngOnInit(): void {
    this.userid = this.authadmin.getUserid();
    this.GetOnUser();
    this.getallCategories();
  }

  generateUUID() {
    this.uuidValue = UUID.UUID();
    return this.uuidValue;
  }

  GetOnUser() {
    this.userserivce.getOneUser(this.userid).subscribe(
      (data) => {
        this.DataUser = data;
      },
      (error: HttpErrorResponse) => {
        Swal.fire('Désolé', error.error.message, 'error');
      }
    );
  }

  getallCategories() {
    this.categorie_type.getAllCategorys().subscribe((data) => {
      this.DataCategorie = data;
    });
  }

  onChangeCategories(categorieId: any) {
    if (categorieId.value) {
      this.categorie_type
        .getType_fournitureByCategorie(categorieId.value)
        .subscribe((data) => {
          this.DataFourniture = data;
        });
    } else {
      this.DataFourniture = null;
    }
  }

  previous() {
    let code = localStorage.getItem('codeDon');

    this.fournitureDon.deleteDonParCode(code).subscribe(
      (data) => {
        localStorage.removeItem('codeDon');
        this.steps = this.steps - 1;
      },
      (err: HttpErrorResponse) => {
        localStorage.removeItem('codeDon');
        this.steps = this.steps - 1;
      }
    );
  }

  next() {
    this.steps = this.steps + 1;
  }

  nouveauDon() {
    this.steps = 1;
  }

  finish() {
    localStorage.removeItem('codeDon');
    this.router.navigate(['/mes-dons']);
  }

  nouveauForniture() {
    this.steps = this.steps - 1;
  }

  addDon(f: any) {
    console.log(f.value);
    this.dataDon.adresse = f.value.adresse;
    this.dataDon.userId = this.userid;
    this.dataDon.code = this.generateUUID();

    localStorage.setItem('codeDon', this.dataDon.code);

    this.fournitureDon.adddon(this.dataDon).subscribe(
      (data) => {
        console.log(data);
        // this.messagesucces = ' ajouter avec success';
        
        Swal.fire('Thank you...',  'Don Ajouter Avec Success', 'success');
        this.steps = this.steps + 1;

        this.fournitureDon
          .getDonByCode(localStorage.getItem('codeDon'))
          .subscribe((res) => {

            let [first] = Object.values(res);

            this.donID = first;
          });
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec denregistrement! :)', 'error');
      }
    );
  }
  addfournitures(four: any) {
    this.dataFourniture.Sexe = four.value.Sexe;
    this.dataFourniture.categoryId = four.value.categoryId;
    this.dataFourniture.couleur = four.value.couleur;
    this.dataFourniture.donId = this.donID;
    this.dataFourniture.niveau = four.value.niveau;
    this.dataFourniture.nombre = four.value.nombre;
    this.dataFourniture.typeFournitureId = four.value.fourniture;

    this.fournitureDon.addFourniture(this.dataFourniture).subscribe(
      (data) => {
        Swal.fire('Thank you...',  'fournitures Ajouter Avec Success', 'success');
        this.steps = this.steps + 1;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec denregistrement! :)', 'error');
      }
    );
  }
}
