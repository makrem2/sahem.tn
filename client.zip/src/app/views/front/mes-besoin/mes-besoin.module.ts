import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MesBesoinRoutingModule } from './mes-besoin-routing.module';
import { MesBesoinComponent } from './mes-besoin/mes-besoin.component';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SafeHtmlPipe } from '../besoin/besoin/safe-html.pipe';


@NgModule({
  declarations: [
    MesBesoinComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    MesBesoinRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule
  ]
})
export class MesBesoinModule { }
