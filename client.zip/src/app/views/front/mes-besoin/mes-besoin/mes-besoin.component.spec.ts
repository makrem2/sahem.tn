import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MesBesoinComponent } from './mes-besoin.component';

describe('MesBesoinComponent', () => {
  let component: MesBesoinComponent;
  let fixture: ComponentFixture<MesBesoinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MesBesoinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MesBesoinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
