import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { BesoinService } from 'src/app/services/besoin.service';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-mes-besoin',
  templateUrl: './mes-besoin.component.html',
  styleUrls: ['./mes-besoin.component.css'],
})
export class MesBesoinComponent implements OnInit {
  Userid: any;
  DataBesoin: any;
  searchbesoin: any;
  idBesoin: any;
  pbesoin: number = 1;
  detail: any;
  besoinn: any;
  constructor(
    private besoin: BesoinService,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.Userid = this.authadmin.getUserid();

    this.getAllUserBesion();
  }

  getAllUserBesion() {
    this.besoin.getAllUserBesion(this.Userid).subscribe(
      (data) => {
        this.DataBesoin = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }

  getdetailBesoin(detail: any, besoin: any) {
    this.detail = detail;

    this.besoinn = besoin;
  }

  getIDBesoin(id: any) {
    this.idBesoin = id;
  }

  DeleteBesoin() {
    this.besoin.deletebesoin(this.idBesoin).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Besoin supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
