import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MesBesoinComponent } from './mes-besoin/mes-besoin.component';

const routes: Routes = [
  {path:'',component:MesBesoinComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MesBesoinRoutingModule { }
