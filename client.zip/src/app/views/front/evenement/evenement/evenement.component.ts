import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { EventBlogService } from 'src/app/services/event-blog.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-evenement',
  templateUrl: './evenement.component.html',
  styleUrls: ['./evenement.component.css'],
})
export class EvenementComponent implements OnInit {
  DataEvent: any;
  imagepath: any = environment.imgUrl;
  pblog: number = 1;
  pevent: number = 1;
  constructor(
    private EventBlogService: EventBlogService,
    private authadmin: AuthserviceService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.GetAllEvent();
  }

  GetAllEvent() {
    this.EventBlogService.getAllEvent().subscribe(
      (data) => {
        this.DataEvent = data;
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  sendIDEvent(id: any) {
    this.router.navigate(['/detail-event'], { queryParams: { eventid: id } });
  }
}
