import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EvenementRoutingModule } from './evenement-routing.module';
import { EvenementComponent } from './evenement/evenement.component';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    EvenementComponent
  ],
  imports: [
    CommonModule,
    EvenementRoutingModule,
    NgxPaginationModule,
  ]
})
export class EvenementModule { }
