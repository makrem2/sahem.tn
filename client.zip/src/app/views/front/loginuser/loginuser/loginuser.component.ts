import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import Swal from 'sweetalert2';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.css'],
})
export class LoginuserComponent implements OnInit {
  formdata: any;
  messagesucces: any;
  messageerror: any;
  visible: boolean = true;
  changetype: boolean = true;
  dataRecevie:any;
  url: any;
  constructor(
    private formBuilder: FormBuilder,
    private authadmin: AuthserviceService,
    private router:Router,
    private ActRoute: ActivatedRoute
  ) {
    if (this.authadmin.UserisLoggedIN()==true){
      this.router.navigate(['/moncompte'])
     }
  }

  ngOnInit(): void {
    this.url = this.ActRoute.snapshot.queryParams['returnUrl'] || '/moncompte';
    this.formdata = this.formBuilder.group({
      username: [
        '',
        [
          Validators.required,
          Validators.maxLength(20),
          Validators.minLength(3),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.maxLength(25),
          Validators.minLength(8),
        ],
      ],
    });
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  login(data: any) {
    this.authadmin.Lougout();
    this.authadmin.login(data).subscribe((data)=>{
      this.dataRecevie = data;

      this.authadmin.SaveDataProfile(this.dataRecevie);

      // this.router.navigate(['../moncompte']); 
      this.router.navigate([this.url]);

    },
    (error: HttpErrorResponse)=>{
      this.messageerror=error.error.message;
      Swal.fire('Désolé', this.messageerror, 'error');
    })
  }
}
