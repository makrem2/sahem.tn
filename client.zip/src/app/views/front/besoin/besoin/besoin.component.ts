import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import Swal from 'sweetalert2';
import { UserServiceService } from 'src/app/services/user-service.service';
import { HttpErrorResponse } from '@angular/common/http';
import { BesoinService } from 'src/app/services/besoin.service';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
@Component({
  selector: 'app-besoin',
  templateUrl: './besoin.component.html',
  styleUrls: ['./besoin.component.css'],
})
export class BesoinComponent implements OnInit {
  steps: any = 1;
  userid: any;
  DataUser: any;
  ville: any = [
    { id: 1, nom: 'Ariana' },
    { id: 2, nom: 'beja' },
    { id: 3, nom: 'Ben Arous' },
    { id: 4, nom: 'Bizerte' },
    { id: 5, nom: 'Gabés' },
    { id: 6, nom: 'Jendouba' },
    { id: 7, nom: 'kairouan' },
    { id: 8, nom: 'Gafsa' },
    { id: 9, nom: 'Kasserine' },
    { id: 10, nom: 'Kebili ' },
    { id: 11, nom: 'kef' },
    { id: 12, nom: 'Mahdia' },
    { id: 13, nom: 'Manouba' },
    { id: 14, nom: 'Medenine' },
    { id: 15, nom: 'Monastir' },
    { id: 16, nom: 'Nabeul' },
    { id: 17, nom: 'Sfax' },
    { id: 18, nom: 'Sidi Bouzid' },
    { id: 19, nom: 'Siliana' },
    { id: 20, nom: 'Sousse' },
    { id: 21, nom: 'Tataouine' },
    { id: 22, nom: 'Tozeur' },
    { id: 23, nom: 'Tunis' },
    { id: 24, nom: 'Zaghouan' },
  ];
  formdata: any;

  formData = {
    besoin: '',
    detail: '',
    adresse: '',
    userId: 0,
  };
  constructor(
    private authadmin: AuthserviceService,
    private route: Router,
    private besoin: BesoinService,
    private userserivce: UserServiceService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.userid = this.authadmin.getUserid();
    this.GetOnUser();
    this.formdata = this.formBuilder.group({
      besoin: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      detail: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
  }

  GetOnUser() {
    this.userserivce.getOneUser(this.userid).subscribe(
      (data) => {
        this.DataUser = data;
      },
      (error: HttpErrorResponse) => {
        Swal.fire('Désolé', error.error.message, 'error');
      }
    );
  }

  AddBesoin(f: any) {
    this.formData.besoin = f.besoin;
    this.formData.detail = f.detail;
    this.formData.adresse = this.DataUser.ville
    this.formData.userId = this.userid;

    this.besoin.addbesoin(this.formData).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Votre Besoin enregistré avec succès: ',
          'success'
        );
      },
      (error: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec denregistré Votre Besoin ! :)', 'error');
      }
    );
  }
}
