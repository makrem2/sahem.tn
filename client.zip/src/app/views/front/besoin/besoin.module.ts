import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BesoinRoutingModule } from './besoin-routing.module';
import { BesoinComponent } from './besoin/besoin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularEditorModule } from '@kolkov/angular-editor';


@NgModule({
  declarations: [
    BesoinComponent
  ],
  imports: [
    CommonModule,
    BesoinRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule
  ]
})
export class BesoinModule { }
