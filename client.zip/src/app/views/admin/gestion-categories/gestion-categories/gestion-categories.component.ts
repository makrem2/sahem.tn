import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CategoriefournitureService } from 'src/app/services/categoriefourniture.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-categories',
  templateUrl: './gestion-categories.component.html',
  styleUrls: ['./gestion-categories.component.css'],
})
export class GestionCategoriesComponent implements OnInit {
  pcategorie: number = 1;
  pfourniture: number = 1;
  searchcategorie: any;
  searchfourniture: any;

  dataCategorie: any;
  dataFourniture: any;

  idcategorie: any;
  idfourniture: any;

  datacategorie = {
    id: 0,
    nom: '',
  };

  datafourniture = {
    id: 0,
    nom: '',
    idcategorie: 0,
  };
  constructor(private Categ_four_Service: CategoriefournitureService) {}

  ngOnInit(): void {
    this.getAllCategorie();
    this.getAllFourniture();
  }

  getAllCategorie() {
    this.Categ_four_Service.getAllCategorys().subscribe(
      (data) => {
        this.dataCategorie = data;
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  addcategorie(cate: any) {
    this.Categ_four_Service.addCategory(cate.value).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Categorie enregistré avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire(
          'Désolé',
          'Échec denregistré cet Categorie ! :)',
          'error'
        );
      }
    );
  }
  getitemtomodifier(id: any, nom: any) {
    this.datacategorie.id = id;
    this.datacategorie.nom = nom;
  }

  GetIdToDelete(idcate: any) {
    this.idcategorie = idcate;
  }

  updatecategorie(dataCategorie: any) {
    this.Categ_four_Service.updateCategory(
      this.datacategorie.id,
      dataCategorie.value
    ).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Categorie modifié avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  DeleteCategorie() {
    this.Categ_four_Service.deletecategorie(this.idcategorie).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Categorie supprimé avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }

  /** ***************** Fourniture    *************                  */

  getAllFourniture() {
    this.Categ_four_Service.getAllFournitures().subscribe(
      (data) => {
        this.dataFourniture = data;
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  addFourniture(Four: any) {
    this.Categ_four_Service.addFournitures(Four.value).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Type Fournitures enregistré avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire(
          'Désolé',
          'Échec denregistré cet type de Fournitures ! :)',
          'error'
        );
      }
    );
  }

  getitemtomodifierFour(id: any, nom: any, idcategorie: any) {
    this.datafourniture.id = id;
    this.datafourniture.nom = nom;
    this.datafourniture.idcategorie = idcategorie;
  }

  updateFourniture(f: any) {
    this.Categ_four_Service.updateFournitures(
      this.datafourniture.id,
      f.value
    ).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Type Fourniture Information modifié avec succès!',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  GetIdToDeleteFour(id: any) {
    this.idfourniture = id;
  }

  DeleteFourniture() {
    this.Categ_four_Service.deleteFournitures(this.idfourniture).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Fourniture supprimé avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
