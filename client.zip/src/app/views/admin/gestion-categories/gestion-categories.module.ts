import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionCategoriesRoutingModule } from './gestion-categories-routing.module';
import { GestionCategoriesComponent } from './gestion-categories/gestion-categories.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    GestionCategoriesComponent
  ],
  imports: [
    CommonModule,
    GestionCategoriesRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
  ]
})
export class GestionCategoriesModule { }
