import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionCompagneRoutingModule } from './gestion-compagne-routing.module';
import { GestionCompagneComponent } from './gestion-compagne/gestion-compagne.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    GestionCompagneComponent
  ],
  imports: [
    CommonModule,
    GestionCompagneRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    AngularEditorModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
  ]
})
export class GestionCompagneModule { }
