import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionCompagneComponent } from './gestion-compagne.component';

describe('GestionCompagneComponent', () => {
  let component: GestionCompagneComponent;
  let fixture: ComponentFixture<GestionCompagneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionCompagneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionCompagneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
