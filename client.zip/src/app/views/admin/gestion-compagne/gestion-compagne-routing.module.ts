import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionCompagneComponent } from './gestion-compagne/gestion-compagne.component';

const routes: Routes = [
  {path:'',component:GestionCompagneComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionCompagneRoutingModule { }
