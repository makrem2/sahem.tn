import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { Role } from 'src/app/_models/role';
import { User } from 'src/app/_models/user';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-utilisateurs',
  templateUrl: './gestion-utilisateurs.component.html',
  styleUrls: ['./gestion-utilisateurs.component.css'],
})
export class GestionUtilisateursComponent implements OnInit {
  p: number = 1;
  searchText: any;
  listusers: any;
  userId: any;
  visible: boolean = true;
  changetype: boolean = true;
  roles: Role[] = [];

  formData={
    yourname:'',
    youremail:'',
    yoursubject:'',
    yourmessage:''
  }

  user: User = new User();
  imagepath: any = environment.imgUrl;
  datauser = {
    id: 0,
    username: '',
    email: '',
    password: '',
  };

  constructor(
    private userservice: UserServiceService,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.userservice.getAllUser().subscribe(
      (data) => {
        this.listusers = data;

        //console.log(this.listusers);
      },
      (err: HttpErrorResponse) => {
        console.log(err);
      }
    );
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  RestMessage() {}

  addAdmin(f: any) {
    this.user.username = f.value.username;
    this.user.password = f.value.password;
    this.user.email = f.value.email;
    this.user.role=f.value.roles
    this.user.roles = [f.value.roles];

    this.formData.yourname=f.value.username;
    this.formData.youremail=f.value.email;
    this.formData.yoursubject='Acces De Site School-out-Box';
    this.formData.yourmessage=f.value.password;

    this.userservice.AddUser(this.user).subscribe(
      (data) => {
        this.userservice.SendMailAssoicationAfterRegister(this.formData).subscribe(
          (data) => {
          },
          (error: HttpErrorResponse) => {
            
            Swal.fire('Thank you...', 'User enregistré avec succès: ', 'success');
            this.ngOnInit();
          }
        );
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  getitemtomodifier(id: any, username: any, email: any) {
    this.datauser.id = id;
    this.datauser.username = username;
    this.datauser.email = email;
  }

  updateAdminUser(u: any) {
    this.userservice.updateAdminUser(this.datauser.id, u.value).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'User Information modifié avec succès! ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  GetIdUserToDelete(id: any) {
    this.userId = id;
  }

  DeleteUser() {
    this.userservice.deleteUser(this.userId).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'User supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
