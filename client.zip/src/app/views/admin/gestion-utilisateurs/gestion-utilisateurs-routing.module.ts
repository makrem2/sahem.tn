import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionUtilisateursComponent } from './gestion-utilisateurs/gestion-utilisateurs.component';

const routes: Routes = [
  {path:'',component:GestionUtilisateursComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionUtilisateursRoutingModule { }
