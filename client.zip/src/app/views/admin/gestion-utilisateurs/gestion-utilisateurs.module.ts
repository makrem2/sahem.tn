import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {NgxPaginationModule} from 'ngx-pagination';
import { GestionUtilisateursRoutingModule } from './gestion-utilisateurs-routing.module';
import { GestionUtilisateursComponent } from './gestion-utilisateurs/gestion-utilisateurs.component';


@NgModule({
  declarations: [
    GestionUtilisateursComponent
  ],
  imports: [
    CommonModule,
    GestionUtilisateursRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
  ]
})
export class GestionUtilisateursModule { }
