import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import { EventBlogService } from 'src/app/services/event-blog.service';
import Swal from 'sweetalert2';

import { AuthserviceService } from 'src/app/services/authservice.service';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-gestion-blog',
  templateUrl: './gestion-blog.component.html',
  styleUrls: ['./gestion-blog.component.css'],
})
export class GestionBlogComponent implements OnInit {
  p: number = 1;
  searchText: any;
  DataBlog: any;
  idblog: any;
  BlogData = {
    id: 0,
    title: '',
    desc: '',
  };
  formdata: any;
  formdataa: any;
  images: any;
  Userid: any;
  imagepath:any=environment.imgUrl
  constructor(
    private EventBlogService: EventBlogService,
    private formBuilder: FormBuilder,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.GetAllBlog();
    this.Userid = this.authadmin.getUserid();
    this.formdata = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
    this.formdataa = this.formBuilder.group({
      title: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      desc: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000000),
          Validators.minLength(5),
        ],
      ],
    });
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const path = event.target.files[0];
      console.log(path);
      this.images = path;
    }
  }

  GetAllBlog() {
    this.EventBlogService.getAllBlog().subscribe(
      (data) => {
        this.DataBlog = data;
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  AddBlog(f: any) {
    const formData = new FormData();

    formData.append('title', f.title);
    formData.append('desc', f.desc);
    formData.append('photo', this.images);
    formData.append('userId', this.Userid);

    this.EventBlogService.addBlog(formData).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Blog enregistré avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec denregistré cet Blog ! :)', 'error');
      }
    );
  }

  getitemtomodifier(id: any, title: any, desc: any) {
    this.BlogData.id = id;
    this.BlogData.title = title;
    this.BlogData.desc = desc;

    console.log(this.BlogData);
  }

  GetIdToDelete(id: any) {
    this.idblog = id;
  }

  updateBlog(f: any) {
    this.EventBlogService.updateBlog(this.BlogData.id, f).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Blog modifié avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la modification ! :)', 'error');
      }
    );
  }

  Deleteblog() {
    this.EventBlogService.deleteBlog(this.idblog).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Blog supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
