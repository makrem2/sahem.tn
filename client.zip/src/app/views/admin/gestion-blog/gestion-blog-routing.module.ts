import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionBlogComponent } from './gestion-blog/gestion-blog.component';

const routes: Routes = [
  {path:'',component:GestionBlogComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionBlogRoutingModule { }
