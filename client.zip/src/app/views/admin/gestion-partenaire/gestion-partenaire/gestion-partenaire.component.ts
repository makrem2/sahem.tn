import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PartenaireService } from 'src/app/services/partenaire.service';
import { environment } from 'src/environments/environment';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-partenaire',
  templateUrl: './gestion-partenaire.component.html',
  styleUrls: ['./gestion-partenaire.component.css'],
})
export class GestionPartenaireComponent implements OnInit {
  DataPartenaire: any;
  idPartenaire: any;
  searchText: any;
  p: number = 1;
  imagepath: any = environment.imgUrl;
  formdata: any;
  images: any;
  constructor(
    private partenaireservice: PartenaireService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.getAllPartenaire();
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const path = event.target.files[0];
      // console.log(path);
      this.images = path;
    }
  }

  getAllPartenaire() {
    this.partenaireservice.getAllPartenaire().subscribe(
      (data) => {
        this.DataPartenaire = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }

  GetIdToDelete(id: any) {
    this.idPartenaire = id;
  }

  AddPartenaire() {
    const formData = new FormData();

    formData.append('photo', this.images);

    this.partenaireservice.addPartenaire(formData).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Partenaire enregistré avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec denregistré cet Partenaire ! :)', 'error');
      }
    );
  }

  DeletePartenaire() {
    this.partenaireservice.deletePartenaire(this.idPartenaire).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Partenaire supprimé avec succès: ',
          'success'
        );
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
