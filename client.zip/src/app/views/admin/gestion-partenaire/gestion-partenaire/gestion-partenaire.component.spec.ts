import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionPartenaireComponent } from './gestion-partenaire.component';

describe('GestionPartenaireComponent', () => {
  let component: GestionPartenaireComponent;
  let fixture: ComponentFixture<GestionPartenaireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionPartenaireComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionPartenaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
