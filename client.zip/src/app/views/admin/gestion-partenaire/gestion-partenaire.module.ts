import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionPartenaireRoutingModule } from './gestion-partenaire-routing.module';
import { GestionPartenaireComponent } from './gestion-partenaire/gestion-partenaire.component';

import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [GestionPartenaireComponent],
  imports: [
    CommonModule,
    GestionPartenaireRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class GestionPartenaireModule {}
