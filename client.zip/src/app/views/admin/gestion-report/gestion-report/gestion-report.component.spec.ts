import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionReportComponent } from './gestion-report.component';

describe('GestionReportComponent', () => {
  let component: GestionReportComponent;
  let fixture: ComponentFixture<GestionReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
