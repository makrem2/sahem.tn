import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ReportService } from 'src/app/services/report.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-report',
  templateUrl: './gestion-report.component.html',
  styleUrls: ['./gestion-report.component.css']
})
export class GestionReportComponent implements OnInit {

  constructor(private reportservice:ReportService) { }
  DataReport:any
  searchText:any
  none='vide'
  p:number=1;  
  imagepath: any = environment.imgUrl;
  reportid:any
  ngOnInit(): void {

    this.reportservice.getAllReport().subscribe((data)=>{
      this.DataReport=data
      console.log(this.DataReport)
    })
  }

  getidreport(id:any){
    this.reportid=id
  }

  deleteReport(){
    this.reportservice.deleteReport(this.reportid).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Report supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }


}
