import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionReportRoutingModule } from './gestion-report-routing.module';
import { GestionReportComponent } from './gestion-report/gestion-report.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    GestionReportComponent
  ],
  imports: [
    CommonModule,
    GestionReportRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class GestionReportModule { }
