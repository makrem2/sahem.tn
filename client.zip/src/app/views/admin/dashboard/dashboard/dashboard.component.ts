import { Component, OnInit } from '@angular/core';
import { BesoinService } from 'src/app/services/besoin.service';
import { CompagneService } from 'src/app/services/compagne.service';
import { FournitureDonService } from 'src/app/services/fourniture-don.service';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  nbcompange: any;
  nbdonEnAttend: any;
  nbDonLivree: any;
  nbAdmin: any;
  nbDonateur: any;
  nbAssociation: any;
  nbbesionEnAttend: any;
  nbbesionLivree: any;
  constructor(
    private donservice: FournitureDonService,
    private compangeservice: CompagneService,
    private userservice: UserServiceService,
    private besionservice:BesoinService
  ) {}

  ngOnInit(): void {
    this.getnbcompange();
    this.getnbdonEnAttend();
    this.getnbDonLivree();
    this.getnbDonateur();
    this.getnbAdmin();
    this.getnbAssociation();
    this.getnbbesionEnAttend();
    this.getnbbesionLivree();
  }

  getnbbesionEnAttend(){

    this.besionservice.getAllBesionBYEtat('EnAttende').subscribe((data)=>{
      this.nbbesionEnAttend=data
    })

  }

  getnbbesionLivree(){
    this.besionservice.getAllBesionBYEtat('livrée').subscribe((data)=>{
      this.nbbesionLivree=data
    })
    
  }

  getnbcompange() {
    this.compangeservice.getAllCompagnes().subscribe((data)=>{
      this.nbcompange=data
    })
  }
  getnbdonEnAttend() {
    this.donservice.getDonParEtat('EnAttende').subscribe((data)=>{
      this.nbdonEnAttend=data
    })
  }
  getnbDonLivree() {
    this.donservice.getDonParEtat('livrée').subscribe((data)=>{
      this.nbDonLivree=data
    })
  }
  getnbDonateur() {
    this.userservice.getAlluserByRole('user').subscribe((data)=>{
      this.nbDonateur=data
    })
  }
  getnbAdmin() {
    this.userservice.getAlluserByRole('admin').subscribe((data)=>{
      this.nbAdmin=data
    })
  }
  getnbAssociation() {
    this.userservice.getAlluserByRole('association').subscribe((data)=>{
      this.nbAssociation=data
    })      
  }
}
