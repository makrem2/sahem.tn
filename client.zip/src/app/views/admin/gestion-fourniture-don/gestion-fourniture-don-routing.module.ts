import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionFournitureDonComponent } from './gestion-fourniture-don/gestion-fourniture-don.component';

const routes: Routes = [
  {path:'',component:GestionFournitureDonComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionFournitureDonRoutingModule { }
