import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { GestionFournitureDonRoutingModule } from './gestion-fourniture-don-routing.module';
import { GestionFournitureDonComponent } from './gestion-fourniture-don/gestion-fourniture-don.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    GestionFournitureDonComponent
  ],
  imports: [
    CommonModule,
    GestionFournitureDonRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
  ]
})
export class GestionFournitureDonModule { }
