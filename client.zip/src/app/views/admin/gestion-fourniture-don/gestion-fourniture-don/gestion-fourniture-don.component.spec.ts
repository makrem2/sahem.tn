import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionFournitureDonComponent } from './gestion-fourniture-don.component';

describe('GestionFournitureDonComponent', () => {
  let component: GestionFournitureDonComponent;
  let fixture: ComponentFixture<GestionFournitureDonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionFournitureDonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionFournitureDonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
