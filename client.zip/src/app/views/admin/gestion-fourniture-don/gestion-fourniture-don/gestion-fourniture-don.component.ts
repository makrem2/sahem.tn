import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { FournitureDonService } from 'src/app/services/fourniture-don.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-fourniture-don',
  templateUrl: './gestion-fourniture-don.component.html',
  styleUrls: ['./gestion-fourniture-don.component.css'],
})
export class GestionFournitureDonComponent implements OnInit {
  pDon: number = 1;
  pFourniture: number = 1;
  searchDon: any;
  searchFourniture: any;
  DataDon: any;
  DataFourniture: any;
  IdDon: any;
  idFourniture: any;
  constructor(
    private FournitureDonService: FournitureDonService,
    private authadmin: AuthserviceService
  ) {}

  ngOnInit(): void {
    this.getAllDon();
  }

  getAllDon() {
    this.FournitureDonService.getAllDon().subscribe(
      (data) => {
        this.DataDon = data;
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  getIDDon(id: any) {
    this.IdDon = id;
    this.FournitureDonService.getAllFournitureBydonId(id).subscribe(
      (data) => {
        this.DataFourniture = data;
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', err.error.message, 'error');
      }
    );
  }

  GetIdFournitureToDelete(idFourniture: any) {
    this.idFourniture = idFourniture;
  }

  DeleteDon() {
    this.FournitureDonService.deleteDon(this.IdDon).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Don supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
  DeleteFourniture() {
    this.FournitureDonService.deleteFourniture(this.idFourniture).subscribe(
      (data) => {
        Swal.fire(
          'Thank you...',
          'Fourniture supprimé avec succès: ',
          'success'
        );
        this.ngOnInit();
        window.location.reload();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
