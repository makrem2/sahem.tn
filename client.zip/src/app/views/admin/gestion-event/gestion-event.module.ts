import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GestionEventRoutingModule } from './gestion-event-routing.module';
import { GestionEventComponent } from './gestion-event/gestion-event.component';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
@NgModule({
  declarations: [
    GestionEventComponent
  ],
  imports: [
    CommonModule,
    GestionEventRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
    
  ]
})
export class GestionEventModule { }
