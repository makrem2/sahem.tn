import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionEventComponent } from './gestion-event/gestion-event.component';

const routes: Routes = [
  {path:'',component:GestionEventComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionEventRoutingModule { }
