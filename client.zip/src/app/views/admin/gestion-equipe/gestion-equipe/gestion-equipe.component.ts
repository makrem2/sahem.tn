import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { EquipeService } from 'src/app/services/equipe.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
@Component({
  selector: 'app-gestion-equipe',
  templateUrl: './gestion-equipe.component.html',
  styleUrls: ['./gestion-equipe.component.css'],
})
export class GestionEquipeComponent implements OnInit {
  DataEquipe: any;
  idequipe: any;
  searchText: any;
  p: number = 1;
  imagepath: any = environment.imgUrl;
  formdata: any;
  images: any;
  constructor(
    private equipeservice: EquipeService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.getAllEquipe();
    this.formdata = this.formBuilder.group({
      nom: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(3),
        ],
      ],
      prenom: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(3),
        ],
      ],
      post: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      facebook: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
      linkedin: [
        '',
        [
          Validators.required,
          Validators.maxLength(250),
          Validators.minLength(5),
        ],
      ],
    });
  }

  selectImage(event: any) {
    if (event.target.files.length > 0) {
      const path = event.target.files[0];
      // console.log(path);
      this.images = path;
    }
  }

  getAllEquipe() {
    this.equipeservice.getAllEquipe().subscribe(
      (data) => {
        this.DataEquipe = data;
      },
      (error: HttpErrorResponse) => {}
    );
  }

  GetIdToDelete(id: any) {
    this.idequipe = id;
  }

  AddEquipe(equipe: any) {
    const formData = new FormData();

    formData.append('nom', equipe.nom);
    formData.append('prenom', equipe.prenom);
    formData.append('post', equipe.post);
    formData.append('facebook', equipe.facebook);
    formData.append('email', equipe.email);
    formData.append('linkedin', equipe.linkedin);
    formData.append('photo', this.images);

    this.equipeservice.addEquipe(formData).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Equipe enregistré avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec denregistré cet Equipe ! :)', 'error');
      }
    );
  }

  DeleteEquipe() {
    this.equipeservice.deleteEquipe(this.idequipe).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Equipe supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (err: HttpErrorResponse) => {
        this.ngOnInit();
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
