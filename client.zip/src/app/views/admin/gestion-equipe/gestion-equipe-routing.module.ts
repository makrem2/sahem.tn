import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionEquipeComponent } from './gestion-equipe/gestion-equipe.component';

const routes: Routes = [
  {path:'',component:GestionEquipeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionEquipeRoutingModule { }
