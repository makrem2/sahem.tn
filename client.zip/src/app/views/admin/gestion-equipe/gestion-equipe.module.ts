import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionEquipeRoutingModule } from './gestion-equipe-routing.module';
import { GestionEquipeComponent } from './gestion-equipe/gestion-equipe.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    GestionEquipeComponent
  ],
  imports: [
    CommonModule,
    GestionEquipeRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class GestionEquipeModule { }
