import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from '../../front/contact/contact/contact.component';
import { GestionContactComponent } from './gestion-contact/gestion-contact.component';

const routes: Routes = [
  {path:'',component:GestionContactComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GestionContactRoutingModule { }
