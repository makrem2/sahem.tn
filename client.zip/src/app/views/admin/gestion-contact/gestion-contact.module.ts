import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GestionContactRoutingModule } from './gestion-contact-routing.module';
import { GestionContactComponent } from './gestion-contact/gestion-contact.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';


@NgModule({
  declarations: [
    GestionContactComponent
  ],
  imports: [
    CommonModule,
    GestionContactRoutingModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class GestionContactModule { }
