import { Component, OnInit } from '@angular/core';
import { ContactService } from 'src/app/services/contact.service';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-gestion-contact',
  templateUrl: './gestion-contact.component.html',
  styleUrls: ['./gestion-contact.component.css'],
})
export class GestionContactComponent implements OnInit {
  p: number = 1;
  searchText: any;
  DataContact: any;
  idcontact: any;
  constructor(private contact: ContactService) {}

  ngOnInit(): void {
    this.contact.getAllContacts().subscribe((data) => {
      this.DataContact = data;
    });
  }

  getContactId(id: any) {
    this.idcontact = id;
  }

  DeleteContact() {
    this.contact.deletecontact(this.idcontact).subscribe(
      (data) => {
        Swal.fire('Thank you...', 'Contact supprimé avec succès: ', 'success');
        this.ngOnInit();
      },
      (error: HttpErrorResponse) => {
        Swal.fire('Désolé', 'Échec de la suppression ! :)', 'error');
      }
    );
  }
}
