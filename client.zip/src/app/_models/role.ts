export enum Role {
    user = 'user',
    admin = 'admin',
    association = 'association'
}