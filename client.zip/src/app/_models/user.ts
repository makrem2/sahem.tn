import { Role } from './role';

export class User {
  id?: number;
  nom?: string;
  prenom?: string;
  adresse?: string;
  domaine?: string;
  date?: string;
  numTEL?: string;
  username?: string;
  email?: string;
  password?: string;
  role?: string;
  roles: Role[] = [];
  token?: string;
}
