const express = require("express");
const cors = require("cors");
const app = express();
const bodyParser = require("body-parser");
const path = require('path')
const nodeMail = require("nodemailer");

var corsOptions = {
  origin: "http://localhost:4200"
};
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Acces-Control-Request-Method", "*");
  res.setHeader("Acces-Control-Allow-Headers", "*");
  next();
});

// Set up CORS
app.use(
  cors({
    origin: true, // "true" will copy the domain of the request back
    // to the reply. If you need more control than this
    // use a function.

    credentials: true, // This MUST be "true" if your endpoint is
    // authenticated via either a session cookie
    // or Authorization header. Otherwise the
    // browser will block the response.

    methods: "POST,GET,PUT,PATCH,OPTIONS,DELETE", // Make sure you're not blocking
    // pre-flight OPTIONS requests
  })
);


app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(express.json());

app.use(bodyParser.json({
  limit: '50mb'
}));

app.use(bodyParser.urlencoded({
  limit: '50mb',
  parameterLimit: 100000,
  extended: true
}));

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

// database
const db = require("./app/models");
const Role = db.role;

db.sequelize.sync();
// force: true will drop the table if it already exists
// db.sequelize.sync({force: true}).then(() => {
//   console.log('Drop and Resync Database with { force: true }');
//   initial();
// });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to School-Out-Box application." });
});

//static Images Folder

app.use("/Images", express.static("./Images"));
app.use(express.static(path.join(__dirname, "static")));

// routes
require('./app/routes/auth.routes')(app);
require('./app/routes/user.routes')(app);
require('./app/routes/blog.routes')(app);
require('./app/routes/Event.routes')(app);
require('./app/routes/category.routes')(app);
require('./app/routes/type_fourniture.routes')(app);
require('./app/routes/don.routes')(app);
require('./app/routes/Fourniture.routes')(app);
require('./app/routes/compagne.routes')(app);
require('./app/routes/besoin.routes')(app);
require('./app/routes/report.routes')(app);
require('./app/routes/contact.routes')(app);
require('./app/routes/equipe.routes')(app);
require('./app/routes/partenaire.routes')(app);


async function mainMail(name, email, subject, password) {
  const transporter = await nodeMail.createTransport({
    service: "gmail",
    auth: {
      user: 'testicstartup@gmail.com',
      pass: 'dbvxndvldymvgvrc',
    },
  });
  const mailOption = {
    from: 'testicstartup@gmail.com',
    to: email,
    subject: subject,
    html: `'Voici le lien de login : http://localhost:4200/association/login' <br>voici l'acces de notre site school-OUTBOX'<br>
    Votre Email : ${email} <br>
    Votre Username: ${name} <br>
    Votre password: ${password}`,
  };
  try {
    await transporter.sendMail(mailOption);
    return Promise.resolve("Message Sent Successfully!");
  } catch (error) {
    console.log(error)
    return Promise.reject(error);
  }
}


app.post("/api/contact", async (req, res, next) => {
  const { yourname, youremail, yoursubject, yourmessage } = req.body;
  try {
    await mainMail(yourname, youremail, yoursubject, yourmessage);

    res.send("Vos Message a été soumises avec succès. Merci !");
  } catch (error) {
    res.send("Message Could not be Sent");
  }
});


// set port, listen for requests
const PORT = process.env.PORT || 8080;

// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });

db.sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`server is running on port ${PORT}`));
});
