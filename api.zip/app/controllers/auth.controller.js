const db = require("../models");
const config = require("../config/auth.config");

const Sequelize = db.sequelize

// image Upload
const multer = require('multer')
const path = require('path')


const User = db.user;
const Role = db.role;

const Op = db.Sequelize.Op;

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.signup = (req, res) => {
  // Save User to Database
  User.create({
    username: req.body.username,
    email: req.body.email,
    role: req.body.role,
    password: bcrypt.hashSync(req.body.password, 8)
  })
    .then(user => {
      if (req.body.roles) {
        Role.findAll({
          where: {
            name: {
              [Op.or]: req.body.roles
            }
          }
        }).then(roles => {

          user.setRoles(roles).then(() => {
            res.send({ message: "User registered successfully!" });
          });
        });
      } else {
        // user role = 3
        user.setRoles([3]).then(() => {
          res.send({ message: "User registered successfully!" });
        });
      }
    })
    .catch(err => {
      res.status(500).send({ message: err.message });
    });
};

exports.signin = (req, res) => {
  User.findOne({
    where: {
      username: req.body.username
    }
  })
    .then(user => {
      if (!user) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        user.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({
          accessToken: null,
          message: "Invalid Password!"
        });
      }

      var token = jwt.sign({ id: user.id }, config.secret, {
        expiresIn: 86400 // 24 hours
      });

      var authorities = [];
      user.getRoles().then(roles => {
        for (let i = 0; i < roles.length; i++) {
          authorities.push("ROLE_" + roles[i].name.toUpperCase());
        }
        res.status(200).send({
          id: user.id,
          username: user.username,
          email: user.email,
          roles: authorities,
          accessToken: token
        });
      });
    })
    .catch(err => {
      res.status(500).send({ message: err.message });
    });
};


exports.getAllUser = async (req, res) => {
  let user = await User.findAll({ include: [db.role] })
  res.status(200).send(user)
};


exports.getAllUserByRegion = async (req, res) => {

  let id = req.params.id

  let role = req.params.role

  let user = await User.findAll({ where: { adresse: id } })
  res.status(200).send(user)

};


exports.getOneUser = async (req, res) => {

  let id = req.params.id
  let user = await User.findOne({ where: { id: id } })
  res.status(200).send(user)

};


exports.getAlluserByRole = async (req, res) => {

  let id = req.params.id
  let user = await User.findAll({ where: { role: id } })
  res.status(200).send(user)

};



exports.getAlluserByRoleANDAdress = async (req, res) => {

  let user = await User.findAll({ where: [{ role: req.params.role }, { ville: req.params.adresse }] })
  res.status(200).send(user)

};





exports.countUserByRole = async (req, res) => {

  let user = await User.findOne({
    attributes: {
      include: [
        [Sequelize.literal('(SELECT COUNT(*) FROM `users` where )'), 'userCount']
      ],
    },

  });

  res.status(200).send(user)

};


exports.deleteUser = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "User was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete User with id=${id}. Maybe User was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete User with id=" + id
      });
    });
};

//. update profil
exports.updateUserImage = async (req, res) => {

  User.update({
    photo: req.file.path
  }, { where: { id: req.params.id } })
    .then((response) => res.status(200).send(response))
    .catch((err) => res.status(400).send(err))
}

exports.updateUser = async (req, res) => {
  User.update({
    nom: req.body.nom,
    prenom: req.body.prenom,
    username: req.body.username,
    organisme: req.body.organisme,
    email: req.body.email,
    password: bcrypt.hashSync(req.body.password, 8),
    numTEL: req.body.numTEL,
    date: req.body.date,
    adresse: req.body.adresse,
    ville: req.body.ville,
    domaine: req.body.domaine
  }, { where: { id: req.params.id } })
    .then((response) => res.status(200).send(response))
    .catch((err) => res.status(400).send(err))
}


exports.updateAdminUser = async (req, res) => {
  User.update({
    username: req.body.username,
    email: req.body.email,
    password: bcrypt.hashSync(req.body.password, 8),
  }, { where: { id: req.params.id } })
    .then((response) => res.status(200).send(response))
    .catch((err) => res.status(400).send(err))
}


// 6. Upload Image Controller

storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'Images')
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname))
  }
})

exports.upload = multer({
  storage: storage,
  limits: { fileSize: '1000000' },
  fileFilter: (req, file, cb) => {
    const fileTypes = /jpeg|jpg|png|gif/
    const mimeType = fileTypes.test(file.mimetype)
    const extname = fileTypes.test(path.extname(file.originalname))

    if (mimeType && extname) {
      return cb(null, true)
    }
    cb('Give proper files formate to upload')
  }
}).single('photo')




