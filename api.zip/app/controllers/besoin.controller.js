const db = require('../models')


// create main Model
const Besoin = db.besoin

// 1. create besoin
const addBesoin = async (req, res) => {

    let info = {
        besoin: req.body.besoin,
        detail: req.body.detail,
        adresse: req.body.adresse,
        userId: req.body.userId,
        etat: "EnAttende"

    }
    const besoin = await Besoin.create(info)
    res.status(200).send(besoin)
    console.log(besoin)

}


//updateEtat 
const updateEtat = async (req, res) => {

    Besoin.update({
        etat: req.body.etat
    }
        , { where: { id: req.params.id } })

        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))
}


// 2. get all Besoin

const getAllBesoins = async (req, res) => {

    let besoins = await Besoin.findAll({ include: [db.user] })
    res.status(200).send(besoins)
}


// 3. get single Besoin

const getOneBesoin = async (req, res) => {

    let id = req.params.id
    let besoin = await Besoin.findOne({ where: { id: id }, include: [db.user] })
    res.status(200).send(besoin)

}


const getAllUserBesion = async (req, res) => {

    let userid = req.params.id
    let besoin = await Besoin.findAll({ where: { userid: userid }, include: [db.user] })
    res.status(200).send(besoin)

}



const getAllBesionBYAdress = async (req, res) => {

    let adresse = req.params.id
    let besoin = await Besoin.findAll({ where: { adresse: adresse }, include: [db.user] })
    res.status(200).send(besoin)

}


const getAllBesionBYEtat = async (req, res) => {

    let etat = req.params.id
    let besoin = await Besoin.findAll({ where: { etat: etat }})
    res.status(200).send(besoin)

}


const getAllAssociationBesionBYEtat = async (req, res) => {

    let besoin = await Besoin.findAll({ where: [{ etat: req.params.etat }, { adresse: req.params.ville }]})
    res.status(200).send(besoin)

}



// 4. update Besoin

const updateBesoin = async (req, res) => {

    Besoin.update({
        besoin: req.body.besoin,
        detail: req.body.detail,
        adresse: req.body.adresse
    }, { where: { id: req.params.id } })
        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))


}

// 5. delete Besoin by id

// Delete a Tutorial with the specified id in the request
const deletebesoin = (req, res) => {
    const id = req.params.id;

    Besoin.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Besoin was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Besoin with id=${id}. Maybe Besoin was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Besoin with id=" + id
            });
        });
};

module.exports = {
    addBesoin,
    getAllBesoins,
    getOneBesoin,
    updateBesoin,
    deletebesoin,
    getAllUserBesion,
    getAllBesionBYAdress,
    updateEtat,
    getAllBesionBYEtat,
    getAllAssociationBesionBYEtat
}