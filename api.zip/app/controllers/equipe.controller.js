const db = require('../models')

// image Upload
const multer = require('multer')
const path = require('path')


// create main Model
const Equipe = db.equipe


// 1. create Event
const addEquipe = async (req, res) => {

    let info = {
        nom: req.body.nom,
        prenom: req.body.prenom,
        post: req.body.post,
        facebook: req.body.facebook,
        email: req.body.email,
        linkedin: req.body.linkedin,
        photo: req.file.path
    }
    const equipe = await Equipe.create(info)
    res.status(200).send(equipe)
}


// 2. get all Equipe

const getAllEquipe = async (req, res) => {

    let equipe = await Equipe.findAll()
    res.status(200).send(equipe)
}

// 5. delete Equipe by id

const deleteEquipe = (req, res) => {
    const id = req.params.id;

    Equipe.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Equipe was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Equipe with id=${id}. Maybe Equipe was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Equipe with id=" + id
            });
        });
};


// 6. Upload Image Controller

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fileSize: '10000000' },
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if (mimeType && extname) {
            return cb(null, true)
        }
        cb('Give proper files formate to upload')
    }
}).single('photo')



module.exports = {
    addEquipe,
    upload,
    getAllEquipe,
    deleteEquipe
}