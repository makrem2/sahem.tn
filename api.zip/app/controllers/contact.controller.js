const db = require('../models')


// create main Model
const Contact = db.contact



// 1. create Contact
const addContact = async (req, res) => {

    let info = {
        nom: req.body.nom,
        email: req.body.email,
        sujet: req.body.sujet,
        message: req.body.message
    }
    const contact = await Contact.create(info)
    res.status(200).send(contact)
}


// 2. get all Category

const getAllContacts = async (req, res) => {

    let contacts = await Contact.findAll({})
    res.status(200).send(contacts)
}



// Delete a Contact with the specified id in the request
const deletecontact = (req, res) => {
    const id = req.params.id;

    Contact.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Contact was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Contact with id=${id}. Maybe Category was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Contact with id=" + id
            });
        });
};



module.exports = {
    addContact,
    deletecontact,
    getAllContacts
}







