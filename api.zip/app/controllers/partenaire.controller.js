const db = require('../models')

// image Upload
const multer = require('multer')
const path = require('path')


// create main Model
const Partenaire = db.partenaire


// 1. create Partenaire
const addPartenaire = async (req, res) => {

    let info = {
        photo: req.file.path
    }
    const partenaire = await Partenaire.create(info)
    res.status(200).send(partenaire)
}


// 2. get all Partenaire

const getAllPartenaire = async (req, res) => {

    let partenaire = await Partenaire.findAll()
    res.status(200).send(partenaire)
}

// 5. delete Partenaire by id

const deletePartenaire = (req, res) => {
    const id = req.params.id;

    Partenaire.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Partenaire was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Partenaire with id=${id}. Maybe Partenaire was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Partenaire with id=" + id
            });
        });
};


// 6. Upload Image Controller

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fileSize: '10000000' },
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif|webp/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if (mimeType && extname) {
            return cb(null, true)
        }
        cb('Give proper files formate to upload')
    }
}).single('photo')



module.exports = {
    addPartenaire,
    upload,
    getAllPartenaire,
    deletePartenaire
}