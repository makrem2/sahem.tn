const db = require('../models')

// image Upload
const multer = require('multer')
const path = require('path')


// create main Model
const Compagne = db.compagne


// 1. create Compagne
const addCompagne = async (req, res) => {

    let info = {
        title: req.body.title,
        sous_desc: req.body.sous_desc,
        desc: req.body.desc,
        photo: req.file.path,
        userId:req.body.userId
    }
    const compagne = await Compagne.create(info)
    res.status(200).send(compagne)
    console.log(compagne)
}


// 2. get all Compagne

const getAllCompagne = async (req, res) => {

    let compagne = await Compagne.findAll({include: [db.user] })
    res.status(200).send(compagne)
}


// 3. get single Compagne

const getOneCompagne = async (req, res) => {

    let id = req.params.id
    let compagne = await Compagne.findOne({ where: { id: id }, include: [db.user] })
    res.status(200).send(compagne)

}


const getAllUserCompagne = async (req, res) => {

    let id = req.params.id
    let compagne = await Compagne.findAll({ where: { userId: id }, include: [db.user] })
    res.status(200).send(compagne)

}


// 4. update Compagne

const updateCompagne = async (req, res) => {

    Compagne.update({
        title: req.body.title,
        desc: req.body.desc
    }, { where: { id: req.params.id } })
        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))

}

// 5. delete Compagne by id

const deleteCompagne = (req, res) => {
    const id = req.params.id;

    Compagne.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Compagne was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Compagne with id=${id}. Maybe Compagne was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Compagne with id=" + id
            });
        });
};






// 6. Upload Image Controller

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fileSize: '10000000' },
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if (mimeType && extname) {
            return cb(null, true)
        }
        cb('Give proper files formate to upload')
    }
}).single('photo')



module.exports = {
    addCompagne,
    upload,
    getAllCompagne,
    getOneCompagne,
    updateCompagne,
    deleteCompagne,
    getAllUserCompagne

}