const db = require('../models')

// image Upload
const multer = require('multer')
const path = require('path')


// create main Model
const Report = db.report


// 1. create Report
const addReport = async (req, res) => {

    let info = {
        desc: req.body.desc,
        photo: req.file.path,
        userId: req.body.userId,
        donId: req.body.donId
    }
    const report = await Report.create(info)
    res.status(200).send(report)
}


// 1. create Report
const addReportBesoin = async (req, res) => {

    let info = {
        desc: req.body.desc,
        photo: req.file.path,
        userId: req.body.userId,
        besoinId: req.body.besoinId
    }
    const report = await Report.create(info)
    res.status(200).send(report)
}



// 2. get all report

const getAllReport = async (req, res) => {

    let report = await Report.findAll({ include: [db.user] })
    res.status(200).send(report)
}

// 5. delete Report by id

const deleteReport = (req, res) => {
    const id = req.params.id;

    Report.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Report was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Report with id=${id}. Maybe Blog was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Report with id=" + id
            });
        });
};


// 6. Upload Image Controller

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fileSize: '10000000' },
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if (mimeType && extname) {
            return cb(null, true)
        }
        cb('Give proper files formate to upload')
    }
}).single('photo')



module.exports = {
    addReport,
    upload,
    getAllReport,
    deleteReport,
    addReportBesoin

}