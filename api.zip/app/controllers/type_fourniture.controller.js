const db = require('../models')


// create main Model
const Type_fourniture = db.type_fournitures

// 1. create Type_fourniture

const addType_fourniture = async (req, res) => {

    let info = {
        nom: req.body.nom,
        categoryId:req.body.categoryId
    }
    const type_fourniture = await Type_fourniture.create(info)
    res.status(200).send(type_fourniture)
    console.log(type_fourniture)

}

// 2. get all Type_fourniture

const getAllType_fourniture = async (req, res) => {

    let type_fourniture = await Type_fourniture.findAll({include: [db.categorie] })
    res.status(200).send(type_fourniture)
}


// 3. get single Category

const getOneType_fourniture = async (req, res) => {

    let id = req.params.id
    let type_fourniture = await Type_fourniture.findOne({ where: { id: id },include: [db.categorie] })
    res.status(200).send(type_fourniture)

}

// 4. update Category

const updateType_fourniture = async (req, res) => {

    Type_fourniture.update({
        nom: req.body.nom,
        categoryId:req.body.categoryId
    }, { where: { id: req.params.id } })
        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))

}

const getType_fournitureByCategorie = async (req, res) => {

    let id = req.params.id
    let type_fourniture = await Type_fourniture.findAll({ where: { categoryId: id }})
    res.status(200).send(type_fourniture)

}

// 5. delete Category by id

// Delete a Tutorial with the specified id in the request
const deleteType_fourniture = (req, res) => {
    const id = req.params.id;

    Type_fourniture.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Type_fourniture was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Type_fourniture with id=${id}. Maybe Type_fourniture was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Type_fourniture with id=" + id
            });
        });
};

module.exports = {
    addType_fourniture,
    getAllType_fourniture,
    getOneType_fourniture,
    updateType_fourniture,
    deleteType_fourniture,
    getType_fournitureByCategorie
}