const db = require('../models')

// create main Model
const Don = db.don


// 1. create Don
const addDon = async (req, res) => {

    Don.create({
        code: req.body.code,
        adresse: req.body.adresse,
        userId: req.body.userId,
        etat: "EnAttende"
    })
        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))

}

// get all don
const getAllDon = async (req, res) => {
    let don = await Don.findAll({ include: [db.fournitures, db.user] })
    res.status(200).send(don)
}


//valider le don 
const validerledon = async (req, res) => {

    Don.update({
        etat: req.body.etat
    }
        , { where: { id: req.params.id } })

        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))
}

const deleteDonParCode = async (req, res, next) => {

    let id = req.params.id

    Don.destroy({
        where: { code: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Don was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Don with id=${id}. Maybe Don was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Don with id=" + id
            });
        });

}

const deleteDon = async (req, res, next) => {

    const id = req.params.id;

    Don.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Don was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Don with id=${id}. Maybe Don was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Don with id=" + id
            });
        });
}

// 6. get don  by region

const getDonByRegion = async (req, res) => {
    const id = req.params.id;
    let don = await Don.findAll({ include: [db.user], where: { adresse: id } })
    res.status(200).send(don)
}


const getdonOfUser = async (req, res) => {
    const id = req.params.id;
    let don = await Don.findAll({ include: [db.user], where: { userId: id } })
    res.status(200).send(don)
}


const getAllAssociationDonBYEtat = async (req, res) => {

    let don = await Don.findAll({ where: [{ etat: req.params.etat }, { adresse: req.params.adresse }]})
    res.status(200).send(don)
}


// get don by code 
const getDonByCode = async (req, res) => {
    let id = req.params.id
    let don = await Don.findOne({ include: [db.user, db.fournitures], where: { code: id } })
    res.status(200).send(don)
}


const getDonParEtat = async (req, res) => {
    let id = req.params.id
    let don = await Don.findAll({where: { etat: id } })
    res.status(200).send(don)
}


module.exports = {
    addDon,
    getAllDon,
    validerledon,
    deleteDon,
    getDonByRegion,
    getdonOfUser,
    getDonByCode,
    deleteDonParCode,
    getDonParEtat,
    getAllAssociationDonBYEtat
}