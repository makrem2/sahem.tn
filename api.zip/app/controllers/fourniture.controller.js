const db = require('../models')


const Fourniture = db.fournitures


//.1 addFourniture
const addFourniture = async (req, res) => {

    Fourniture.create({
        nombre: req.body.nombre,
        Sexe: req.body.Sexe,
        couleur: req.body.couleur,
        niveau: req.body.niveau,
        categoryId: req.body.categoryId,
        donId: req.body.donId,
        typeFournitureId: req.body.typeFournitureId
    })

        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))
}

//.2 deleteFourniture
const deleteFourniture = async (req, res, next) => {

    const id = req.params.id;

    Fourniture.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Fourniture was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Fourniture with id=${id}. Maybe Fourniture was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Fourniture with id=" + id
            });
        });

}

const getAllFourniture = async (req, res) => {

    let fournitures = await Fourniture.findAll({ include: [db.categorie, db.type_fournitures, db.don] })
    res.status(200).send(fournitures)
}

//.3 getAllFourniture
const getAllFournitureBydonId = async (req, res) => {
    let id = req.params.id
    let don = await Fourniture.findAll({ include: [db.type_fournitures, db.categorie], where: { donId: id } })
    res.status(200).send(don)
}


module.exports = {
    addFourniture,
    deleteFourniture,
    getAllFourniture,
    getAllFournitureBydonId
}