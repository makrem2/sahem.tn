const db = require('../models')

// image Upload
const multer = require('multer')
const path = require('path')


// create main Model
const Event = db.event


// 1. create Event
const addEvent = async (req, res) => {

    let info = {
        title: req.body.title,
        desc: req.body.desc,
        photo: req.file.path,
        userId: req.body.userId
    }
    const event = await Event.create(info)
    res.status(200).send(event)
    console.log(event)
}


// 2. get all Event

const getAllEvent = async (req, res) => {

    let event = await Event.findAll({ include: [db.user] })
    res.status(200).send(event)
}



const getAllUserEvent = async (req, res) => {

    let id = req.params.id
    let event = await Event.findAll({ where: { userId: id }, include: [db.user] })
    res.status(200).send(event)

}

// 3. get single Event

const getOneEvent = async (req, res) => {

    let id = req.params.id
    let event = await Event.findOne({ where: { id: id }, include: [db.user] })
    res.status(200).send(event)

}

// 4. update Event

const updateEvent = async (req, res) => {

    Event.update({
        title: req.body.title,
        desc: req.body.description
    }, { where: { id: req.params.id } })
        .then((response) => res.status(200).send(response))
        .catch((err) => res.status(400).send(err))

}

// 5. delete Blog by id

const deleteEvent = (req, res) => {
    const id = req.params.id;

    Event.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Event was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Event with id=${id}. Maybe Event was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Event with id=" + id
            });
        });
};






// 6. Upload Image Controller

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fileSize: '10000000' },
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if (mimeType && extname) {
            return cb(null, true)
        }
        cb('Give proper files formate to upload')
    }
}).single('photo')



module.exports = {
    addEvent,
    upload,
    getAllEvent,
    getOneEvent,
    updateEvent,
    deleteEvent,
    getAllUserEvent

}