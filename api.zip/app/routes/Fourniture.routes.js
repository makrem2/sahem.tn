const { authJwt } = require("../middleware");
const FournitureController = require("../controllers/fourniture.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });
    app.get("/api/fourniture/getAllFournitureBydonId/:id",[authJwt.verifyToken, authJwt.isAssociationOrAdminoruser],FournitureController.getAllFournitureBydonId);
    app.get("/api/fourniture/getAllFourniture",[authJwt.verifyToken, authJwt.isAssociationOrAdminoruser],FournitureController.getAllFourniture);
    app.post('/api/fourniture/addFourniture', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], FournitureController.addFourniture)
    app.delete('/api/fourniture/deleteFourniture/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], FournitureController.deleteFourniture)
};