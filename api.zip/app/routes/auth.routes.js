const { verifySignUp } = require("../middleware");
const { authJwt } = require("../middleware");
const controller = require("../controllers/auth.controller");

module.exports = function (app) {
  app.use(function (req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  app.post(
    "/api/auth/signup",
    [
      verifySignUp.checkDuplicateUsernameOrEmail,
      verifySignUp.checkRolesExisted
    ],
    controller.signup
  );

  app.post("/api/auth/signin", controller.signin);

  app.get('/api/auth/getAllUser', [authJwt.verifyToken, authJwt.isAdmin], controller.getAllUser)

  app.get('/api/auth/getAllUserByRegion/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.getAllUserByRegion)

  app.get('/api/auth/getOneUser/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.getOneUser)

  app.get('/api/auth/getAlluserByRole/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.getAlluserByRole)

  app.get('/api/auth/getAlluserByRoleANDAdress/:role/:adresse',[authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.getAlluserByRoleANDAdress)


  app.get('/api/auth/countUserByRole', controller.countUserByRole)

  app.delete('/api/auth/deleteUser/:id', [authJwt.verifyToken, authJwt.isAdmin], controller.deleteUser)

  app.patch('/api/auth/updateAdminUser/:id', [authJwt.verifyToken, authJwt.isAdmin], controller.updateAdminUser)

  app.patch('/api/auth/updateUser/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.updateUser)

  app.patch('/api/auth/updateUserImage/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], controller.upload, controller.updateUserImage)
};
