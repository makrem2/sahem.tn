const { authJwt } = require("../middleware");
const reportController = require("../controllers/report.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.post('/api/Report/addReportBesoin', [authJwt.verifyToken, authJwt.isAssociation], reportController.upload, reportController.addReportBesoin)
    

    app.get(
        "/api/Report/getAllReport",
        reportController.getAllReport
    );

    app.post('/api/Report/addReport', [authJwt.verifyToken, authJwt.isAssociation], reportController.upload, reportController.addReport)

    app.delete('/api/Report/deleteReport/:id', [authJwt.verifyToken, authJwt.isAdmin], reportController.deleteReport)
};