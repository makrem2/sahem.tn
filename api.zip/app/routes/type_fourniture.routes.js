const { authJwt } = require("../middleware");
const type_fournituresController = require("../controllers/type_fourniture.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/fourniture/getAllType_fourniture",
        type_fournituresController.getAllType_fourniture
    );

    app.post('/api/fourniture/addType_fourniture', [authJwt.verifyToken, authJwt.isAdmin], type_fournituresController.addType_fourniture)

    app.get('/api/fourniture/getType_fournitureByCategorie/:id', type_fournituresController.getType_fournitureByCategorie)

    app.get('/api/fourniture/getOneType_fourniture/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], type_fournituresController.getOneType_fourniture)

    app.patch('/api/fourniture/updateType_fourniture/:id', [authJwt.verifyToken, authJwt.isAdmin], type_fournituresController.updateType_fourniture)

    app.delete('/api/fourniture/deleteType_fourniture/:id', [authJwt.verifyToken, authJwt.isAdmin], type_fournituresController.deleteType_fourniture)
};