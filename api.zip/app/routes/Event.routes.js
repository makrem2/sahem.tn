const { authJwt } = require("../middleware");
const EventController = require("../controllers/event-controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/event/getAllEvent",
        EventController.getAllEvent
    );

    app.post('/api/event/addEvent', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], EventController.upload, EventController.addEvent)


    app.get('/api/event/getAllUserEvent/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], EventController.getAllUserEvent)

    app.get('/api/event/getOneEvent/:id', EventController.getOneEvent)

    app.patch('/api/event/updateEvent/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], EventController.upload, EventController.updateEvent)

    app.delete('/api/event/deleteEvent/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], EventController.deleteEvent)
};