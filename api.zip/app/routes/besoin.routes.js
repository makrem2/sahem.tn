const { authJwt } = require("../middleware");
const besoinController = require("../controllers/besoin.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/besoin/getAllBesoins",
        besoinController.getAllBesoins
    );

    app.post('/api/besoin/addBesoin', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.addBesoin)
    


    app.get('/api/besoin/getAllBesionBYAdress/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.getAllBesionBYAdress)

    app.patch('/api/besoin/updateEtat/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.updateEtat)

    app.get('/api/besoin/getAllUserBesion/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.getAllUserBesion)

    app.get('/api/besoin/getOneBesoin/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.getOneBesoin)

    app.get('/api/besoin/getAllBesionBYEtat/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.getAllBesionBYEtat)

    app.patch('/api/besoin/updateBesoin/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.updateBesoin)

    app.delete('/api/besoin/deletebesoin/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.deletebesoin)

    app.get('/api/besoin/getAllAssociationBesionBYEtat/:etat/:ville', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], besoinController.getAllAssociationBesionBYEtat)

    
};