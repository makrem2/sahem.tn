const { authJwt } = require("../middleware");
const compagneController = require("../controllers/compagne.controller.js");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/compagne/getAllCompagne",
        compagneController.getAllCompagne
    );

    app.post('/api/compagne/addCompagne', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], compagneController.upload, compagneController.addCompagne)

    app.get('/api/compagne/getAllUserCompagne/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], compagneController.getAllUserCompagne)

    app.get('/api/compagne/getOneCompagne/:id', compagneController.getOneCompagne)

    app.patch('/api/compagne/updateCompagne/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], compagneController.upload, compagneController.updateCompagne)

    app.delete('/api/compagne/deleteCompagne/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], compagneController.deleteCompagne)
};