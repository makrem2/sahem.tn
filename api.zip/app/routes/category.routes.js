const { authJwt } = require("../middleware");
const categoryController = require("../controllers/categorie.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/category/getAllCategorys",
        categoryController.getAllCategorys
    );

    app.post('/api/category/addCategory', [authJwt.verifyToken, authJwt.isAdmin], categoryController.addCategory)


    app.get('/api/category/getOneCategory/:id', [authJwt.verifyToken, authJwt.isAdmin], categoryController.getOneCategory)

    app.patch('/api/category/updateCategory/:id', [authJwt.verifyToken, authJwt.isAdmin],categoryController.updateCategory)

    app.delete('/api/category/deletecategorie/:id', [authJwt.verifyToken, authJwt.isAdmin], categoryController.deletecategorie)
};