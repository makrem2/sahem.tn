const { authJwt } = require("../middleware");
const ContactController = require("../controllers/contact.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });


    app.post('/api/Contacts/addContact', ContactController.addContact)

    app.get("/api/Contacts/getAllContacts",[authJwt.verifyToken, authJwt.isAdmin], ContactController.getAllContacts);

    app.delete('/api/Contacts/deletecontact/:id', [authJwt.verifyToken, authJwt.isAdmin], ContactController.deletecontact)
};