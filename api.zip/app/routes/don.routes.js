const { authJwt } = require("../middleware");
const donController = require("../controllers/don.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.post('/api/don/adddon', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.addDon)
    app.get("/api/don/getAllDon", [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getAllDon);
    app.patch('/api/don/validerledon/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.validerledon)
    app.delete('/api/don/deleteDon/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.deleteDon)
    app.delete('/api/don/deleteDonParCode/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.deleteDonParCode)
    app.get('/api/don/getDonByRegion/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getDonByRegion)
    app.get('/api/don/getdonOfUser/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getdonOfUser)
    app.get('/api/don/getDonByCode/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getDonByCode)

    app.get('/api/don/getDonParEtat/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getDonParEtat)
    
    app.get('/api/don/getAllAssociationDonBYEtat/:etat/:adresse', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], donController.getAllAssociationDonBYEtat)
};