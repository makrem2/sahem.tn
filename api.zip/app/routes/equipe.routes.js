const { authJwt } = require("../middleware");
const EquipeController = require("../controllers/equipe.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get("/api/Equipe/getAllEquipe", EquipeController.getAllEquipe);

    app.post('/api/Equipe/addEquipe', [authJwt.verifyToken, authJwt.isAdmin], EquipeController.upload, EquipeController.addEquipe)

    app.delete('/api/Equipe/deleteEquipe/:id', [authJwt.verifyToken, authJwt.isAdmin], EquipeController.deleteEquipe)
};