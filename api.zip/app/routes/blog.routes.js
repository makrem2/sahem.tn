const { authJwt } = require("../middleware");
const blogController = require("../controllers/blog.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/blog/getAllBlog",
        blogController.getAllBlog
    );

    app.post('/api/blog/addBlog', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], blogController.upload, blogController.addBlog)

    app.get('/api/blog/getAllUserBlog/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], blogController.getAllUserBlog)

    app.get('/api/blog/getOneBlog/:id', blogController.getOneBlog)

    app.patch('/api/blog/updateBlog/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], blogController.upload, blogController.updateBlog)

    app.delete('/api/blog/deleteBlog/:id', [authJwt.verifyToken, authJwt.isAssociationOrAdminoruser], blogController.deleteBlog)
};