module.exports = (sequelize,DataType) => {
    const Categorie = sequelize.define("categories", {
        nom:{
            type:DataType.STRING,
            allowNull:false
        }
    });

    return Categorie;
};
