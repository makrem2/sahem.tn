const config = require("../config/db.config.js");

const Sequelize = require("sequelize");
const sequelize = new Sequelize(
  config.DB,
  config.USER,
  config.PASSWORD,
  {
    host: config.HOST,
    dialect: config.dialect,
    operatorsAliases: false,

    pool: {
      max: config.pool.max,
      min: config.pool.min,
      acquire: config.pool.acquire,
      idle: config.pool.idle
    }
  }
);

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require("../models/user.model.js")(sequelize, Sequelize);
db.role = require("../models/role.model.js")(sequelize, Sequelize);
db.event = require("../models/event.model.js")(sequelize, Sequelize);
db.blog = require("../models/blog.model.js")(sequelize, Sequelize);
db.categorie = require("../models/categorie.model.js")(sequelize, Sequelize);
db.don = require("../models/don.model.js")(sequelize, Sequelize);
db.fournitures = require("../models/fourniture.model.js")(sequelize, Sequelize);
db.type_fournitures = require("../models/type_fourniture.model.js")(sequelize, Sequelize);
db.compagne = require("../models/compagne.model.js")(sequelize, Sequelize);
db.besoin = require("../models/besoin.model.js")(sequelize, Sequelize);
db.report = require("../models/report.model.js")(sequelize, Sequelize);
db.contact = require("../models/contact.model")(sequelize, Sequelize);
db.equipe = require("../models/equipe.model")(sequelize, Sequelize);

db.partenaire = require("../models/partenaires.model")(sequelize, Sequelize);
//user assoiciation

db.role.belongsToMany(db.user, {
  through: "user_roles",
  foreignKey: "roleId",
  otherKey: "userId"
});
db.user.belongsToMany(db.role, {
  through: "user_roles",
  foreignKey: "userId",
  otherKey: "roleId"
});


//Report user AND Don

db.user.hasMany(db.report, {
  onDelete: "cascade"
});

db.report.belongsTo(db.user, {
  onDelete: "cascade"
});


db.don.hasMany(db.report, {
  onDelete: "cascade"
});

db.report.belongsTo(db.don, {
  onDelete: "cascade"
});


db.besoin.hasMany(db.report, {
  onDelete: "cascade"
});

db.report.belongsTo(db.besoin, {
  onDelete: "cascade"
});


//besion user

db.user.hasMany(db.besoin, {
  onDelete: "cascade"
});

db.besoin.belongsTo(db.user, {
  onDelete: "cascade"
});

//blog assoiciation

db.user.hasMany(db.blog, {
  onDelete: "cascade"
});

db.blog.belongsTo(db.user, {
  onDelete: "cascade"
});

//compagne assoiciation

db.user.hasMany(db.compagne, {
  onDelete: "cascade"
});

db.compagne.belongsTo(db.user, {
  onDelete: "cascade"
});

//event assoiciation

db.user.hasMany(db.event, {
  onDelete: "cascade"
});

db.event.belongsTo(db.user, {
  onDelete: "cascade"
});

// don assoiciation

db.don.hasMany(db.fournitures, {
  onDelete: "cascade"
});
db.don.belongsTo(db.user, {
  onDelete: "cascade"
});

// categorie assoiciation

db.categorie.hasMany(db.fournitures, {
  onDelete: "cascade"
});
db.categorie.hasMany(db.type_fournitures, {
  onDelete: "cascade"
});

// fourniture assoiciation

db.fournitures.belongsTo(db.don, {
  onDelete: "cascade"
});
db.fournitures.belongsTo(db.categorie, {
  onDelete: "cascade"
});
db.fournitures.belongsTo(db.type_fournitures, {
  onDelete: "cascade"
});

// fourniture assoiciation

db.type_fournitures.hasMany(db.fournitures, {
  onDelete: "cascade"
});
db.type_fournitures.belongsTo(db.categorie, {
  onDelete: "cascade"
});


db.ROLES = ["user", "admin", "association"];

module.exports = db;
