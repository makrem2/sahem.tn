module.exports = (sequelize, Sequelize) => {
    const Equipe = sequelize.define("equipes", {
      nom: {
        type: Sequelize.STRING
      },
      prenom: {
        type: Sequelize.STRING
      },
      post: {
        type: Sequelize.STRING
      },
      facebook: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING
      },
      linkedin: {
        type: Sequelize.STRING
      },
      photo: {
        type: Sequelize.STRING
      }
    });
  
    return Equipe;
  };
  