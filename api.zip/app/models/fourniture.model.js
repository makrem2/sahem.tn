module.exports = (sequelize, DataType) => {
    const Fourniture = sequelize.define("fournitures", {
        nombre: {
            type: DataType.STRING,

        },
        Sexe: {
            type: DataType.STRING,

        },
        couleur: {
            type: DataType.STRING,

        },
        niveau: {
            type: DataType.STRING,

        }
    });

    return Fourniture;
};
