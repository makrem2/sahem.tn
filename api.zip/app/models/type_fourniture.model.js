module.exports = (sequelize, DataType) => {
    const Type_fourniture = sequelize.define("type_fournitures", {
        nom: {
            type: DataType.STRING,

        }
    });

    return Type_fourniture;
};
