module.exports = (sequelize,DataType) => {
    const Besoin = sequelize.define("besoins", {
        besoin: {
            type: DataType.STRING(15000),
            required: true,
        },
        detail: {
            type: DataType.STRING(15000),
            required: true,

        },
        adresse: {
            type: DataType.STRING(250),
            required: true,

        },
        etat:{
            type:DataType.STRING
            
        }

        
    });

    return Besoin;
};
