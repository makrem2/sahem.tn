module.exports = (sequelize,DataType) => {
    const Event = sequelize.define("events", {
        title: {
            type: DataType.STRING(15000),
            required: true,
        },
        desc: {
            type: DataType.STRING(15000),
            required: true,

        },
        photo: {
            type: DataType.STRING,
            required: false,
        }
    });

    return Event;
};
