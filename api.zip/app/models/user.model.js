module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("users", {
    nom: {
      type: Sequelize.STRING
    },
    prenom: {
      type: Sequelize.STRING
    },
    organisme: {
      type: Sequelize.STRING
    },
    ville: {
      type: Sequelize.STRING
    },
    adresse: {
      type: Sequelize.STRING
    },
    domaine: {
      type: Sequelize.STRING
    },
    date: {
      type: Sequelize.STRING
    },
    numTEL: {
      type: Sequelize.STRING
    },
    photo: {
      type: Sequelize.STRING
    },
    username: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
    role: {
      type: Sequelize.STRING
    }
  });

  return User;
};
