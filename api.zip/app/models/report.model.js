module.exports = (sequelize,DataType) => {
    const Report = sequelize.define("reports", {
        desc: {
            type: DataType.STRING(15000),
            required: true,

        },
        photo: {
            type: DataType.STRING,
            required: false,
        }
    });

    return Report;
};
