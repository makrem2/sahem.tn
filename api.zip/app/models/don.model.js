module.exports = (sequelize,DataType) => {
    const Don = sequelize.define("dons", {
        code:{
            type:DataType.STRING
           
        },
        adresse:{
            type:DataType.STRING
            
        },
        etat:{
            type:DataType.STRING
            
        }
    });
    

    return Don;
};
