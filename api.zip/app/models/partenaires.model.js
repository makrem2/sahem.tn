module.exports = (sequelize, Sequelize) => {
    const Partenaire = sequelize.define("partenaires", {

      photo: {
        type: Sequelize.STRING
      }
    });
  
    return Partenaire;
  };
  