module.exports = (sequelize,DataType) => {
    const Compagne = sequelize.define("compagnes", {
        title: {
            type: DataType.STRING(15000),
            required: true,
        },
        sous_desc: {
            type: DataType.STRING(15000),
            required: true,

        },
        desc: {
            type: DataType.STRING(15000),
            required: true,

        },
        photo: {
            type: DataType.STRING,
            required: false,
        }
    });

    return Compagne;
};
