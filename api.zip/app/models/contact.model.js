module.exports=(sequelize,DataType)=>{
    const Contact=sequelize.define("contacts",{
        nom:{
            type:DataType.STRING,
            allowNull:false
        },
        email:{
            type:DataType.STRING,
            allowNull:false
        },
        sujet:{
            type:DataType.STRING,
            allowNull:false
        },
        message:{
            type:DataType.STRING,
            allowNull:false
        }
    })

return Contact
}